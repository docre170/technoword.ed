$techno = "php"
$lignes = foreach ($f in Get-ChildItem "resultats\${techno}_vu*.json") {
  if ($f.BaseName -match '^(.+)_vu(\d+)_(\d+)$') {
    $j = Get-Content $f.FullName -Raw | ConvertFrom-Json
    $d = $j.metrics.http_req_duration; if ($d.values) { $d = $d.values }
    $r = $j.metrics.http_reqs;         if ($r.values) { $r = $r.values }
    $e = $j.metrics.http_req_failed;   if ($e.values) { $e = $e.values }
    [pscustomobject]@{
      technologie = $matches[1]; utilisateurs = [int]$matches[2]; essai = [int]$matches[3]
      moyenne_ms = $d.avg; mediane_ms = $d.med; p95_ms = $d.'p(95)'; p99_ms = $d.'p(99)'; max_ms = $d.max
      debit_rps = $r.rate; erreurs = $e.value
    }
  }
}
$lignes | Sort-Object utilisateurs, essai | Export-Csv "donnees_brutes_$techno.csv" -NoTypeInformation -Encoding UTF8
"$($lignes.Count) lignes"