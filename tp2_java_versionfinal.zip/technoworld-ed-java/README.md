# TechnoWorld Ed — module catalogue

API Java 21 / Spring Boot 3.3.13, utilisant uniquement `spring-boot-starter-web`.

## Build and launch

Run these commands from this folder:

```bash
mvnd -q clean package
java -jar target/catalogue.jar
```

The service listens on `127.0.0.1:8080`. Keep the `data` folder beside the
project when launching from this folder. The app also checks for `data` beside
the jar first, then falls back to the current working directory.

The supplied `data/cours.json` and `data/resultats.json` files are loaded once
at startup. Creating a course updates the in-memory catalogue and replaces
`data/cours.json` through a temporary file in the same directory.

## Roles and learning features

Open `http://127.0.0.1:8080/` to browse published courses, sign in, or create
an apprenant account. Public registration cannot select a privileged role.
Accounts are stored in `data/utilisateurs.json`; passwords are salted and
hashed with PBKDF2-HMAC-SHA256. Session cookies are HTTP-only and use
SameSite=Lax.

Configure the first administrator before starting the application by setting
both `TECHNOWORLD_ADMIN_EMAIL` and `TECHNOWORLD_ADMIN_PASSWORD` in its
environment. The password must contain at least 12 characters. If the email
already belongs to an account and no administrator exists, that account is
promoted and its password is set to the configured value. Once an
administrator exists, the bootstrap variables do not change existing accounts.
Administrators can create teacher and learner accounts and change roles in the
Administration page.

Learning data is stored separately in `data/plateforme.json`; legacy
`cours.json` and `resultats.json` remain available to the original catalogue
and k6 benchmark routes. Existing courses are treated as published in the
learning catalogue. Teacher-created courses and their lessons and quizzes
remain pending until an administrator approves them. Learners can enroll in
published courses, access their lessons and quizzes, track progress, see their
scores, and view a simple quiz-score ranking. Correct quiz answers are returned
only to the owning teacher's management endpoints; scores are computed and
stored by the server.

The authentication API provides `POST /api/auth/inscription`,
`POST /api/auth/connexion`, `GET /api/auth/session`, and
`POST /api/auth/deconnexion`. The visitor API provides `GET /api/categories`,
`GET /api/courses`, and `GET /api/courses/{courseId}`. Learner endpoints
include `POST /api/courses/{courseId}/enroll`, `GET /api/me/courses`,
`POST /api/courses/{courseId}/lessons/{lessonId}/complete`,
`GET /api/courses/{courseId}/quizzes`,
`POST /api/courses/{courseId}/quizzes/{quizId}/attempts`,
`GET /api/me/results`, and `GET /api/ranking`.

Teacher endpoints under `/api/teacher/courses` support owned course and lesson
management and quiz creation. Administrator endpoints under `/api/admin`
support account management, category management, and course approval or
refusal. These endpoints validate the active session and role on every
request, and teacher course operations enforce ownership.

The original `GET /cours`, `GET /cours/recherche`, and
`GET /cours/{id}/moyenne` catalogue behavior is unchanged. For access control
and approval, `POST /cours` now requires an enseignant session and creates a
pending proposal; new application screens use the role-aware `/api` endpoints.
