package com.technoworld.catalogue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Pattern;

@Component
public class CatalogueStore {
    private static final int PAGE_SIZE = 20;
    private static final int SEARCH_LIMIT = 50;

    private final ObjectMapper objectMapper;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private List<ObjectNode> courses = new ArrayList<>();
    private final Map<Integer, List<Double>> scoresByCourse = new HashMap<>();
    private final Set<String> titles = new HashSet<>();

    private Path dataDirectory;
    private Path coursesFile;
    private int lastId;

    public CatalogueStore(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public Path getDataDirectory() {
        return dataDirectory;
    }

    @PostConstruct
    public void loadData() throws IOException {
        dataDirectory = locateDataDirectory();
        coursesFile = dataDirectory.resolve("cours.json");

        JsonNode courseData = readJsonArray(coursesFile);
        if (!courseData.isArray()) {
            throw new IOException("Le fichier cours.json doit contenir une liste JSON.");
        }

        for (JsonNode row : courseData) {
            ObjectNode course = normalizeCourse(row);
            courses.add(course);
            titles.add(course.path("titre").textValue());
            lastId = course.path("id").intValue();
        }
        courses.sort(Comparator.comparingInt(course -> course.path("id").intValue()));

        JsonNode resultData = readJsonArray(dataDirectory.resolve("resultats.json"));
        if (!resultData.isArray()) {
            throw new IOException("Le fichier resultats.json doit contenir une liste JSON.");
        }

        for (JsonNode row : resultData) {
            if (!row.isObject()
                    || !row.path("cours_id").canConvertToInt()
                    || !row.path("score").isNumber()) {
                throw new IOException("Format de résultat invalide.");
            }
            int courseId = row.path("cours_id").intValue();
            scoresByCourse.computeIfAbsent(courseId, ignored -> new ArrayList<>())
                    .add(row.path("score").doubleValue());
        }
    }

    public ObjectNode listCourses(long page) {
        lock.readLock().lock();
        try {
            ObjectNode data = objectMapper.createObjectNode();
            data.put("page", page);
            data.put("par_page", PAGE_SIZE);
            data.put("total", courses.size());

            ArrayNode items = objectMapper.createArrayNode();
            long start = (page - 1) > Long.MAX_VALUE / PAGE_SIZE
                    ? Long.MAX_VALUE
                    : (page - 1) * PAGE_SIZE;
            if (start < courses.size()) {
                int from = (int) start;
                int to = Math.min(from + PAGE_SIZE, courses.size());
                for (int index = from; index < to; index++) {
                    items.add(courses.get(index));
                }
            }
            data.set("items", items);
            return data;
        } finally {
            lock.readLock().unlock();
        }
    }

    public List<ObjectNode> allCourses() {
        lock.readLock().lock();
        try {
            List<ObjectNode> snapshot = new ArrayList<>(courses.size());
            courses.forEach(course -> snapshot.add(course.deepCopy()));
            return snapshot;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode searchCourses(String query) {
        lock.readLock().lock();
        try {
            String normalizedQuery = query.toLowerCase(Locale.ROOT);
            ArrayNode items = objectMapper.createArrayNode();
            int returned = 0;

            for (ObjectNode course : courses) {
                String title = course.path("titre").textValue().toLowerCase(Locale.ROOT);
                String description = course.path("description").textValue().toLowerCase(Locale.ROOT);
                if (title.contains(normalizedQuery) || description.contains(normalizedQuery)) {
                    items.add(course);
                    returned++;
                    if (returned == SEARCH_LIMIT) {
                        break;
                    }
                }
            }

            ObjectNode data = objectMapper.createObjectNode();
            data.put("total", returned);
            data.set("items", items);
            return data;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode averageForCourse(int courseId) {
        lock.readLock().lock();
        try {
            boolean exists = courses.stream()
                    .anyMatch(course -> course.path("id").intValue() == courseId);
            if (!exists) {
                throw new CatalogueApiException(404, "Cours introuvable.");
            }

            List<Double> scores = scoresByCourse.getOrDefault(courseId, List.of());
            ObjectNode data = objectMapper.createObjectNode();
            data.put("cours_id", courseId);
            data.put("nombre_resultats", scores.size());

            if (scores.isEmpty()) {
                data.putNull("moyenne");
            } else {
                double sum = 0.0;
                for (double score : scores) {
                    sum += score;
                }
                double rounded = Math.floor(((sum / scores.size()) + Math.ulp(1.0)) * 100 + 0.5) / 100;
                data.put("moyenne", BigDecimal.valueOf(rounded).stripTrailingZeros());
            }
            return data;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode createCourse(String title, String description, String category, String author)
            throws IOException {
        lock.writeLock().lock();
        try {
            if (titles.contains(title)) {
                throw new CatalogueApiException(409, "Ce titre existe déjà.");
            }

            int newId = lastId + 1;
            ObjectNode course = objectMapper.createObjectNode();
            course.put("id", newId);
            course.put("titre", title);
            course.put("description", description);
            course.put("categorie", category);
            course.put("auteur", author);

            List<ObjectNode> updatedCourses = new ArrayList<>(courses);
            updatedCourses.add(course);
            updatedCourses.sort(Comparator.comparingInt(item -> item.path("id").intValue()));
            writeCourses(updatedCourses);

            courses = updatedCourses;
            titles.add(title);
            lastId = newId;
            return course;
        } finally {
            lock.writeLock().unlock();
        }
    }

    private Path locateDataDirectory() throws IOException {
        List<Path> candidates = new ArrayList<>();
        String javaClassPath = System.getProperty("java.class.path", "");
        if (!javaClassPath.isBlank()) {
            String firstClassPathEntry = javaClassPath.split(Pattern.quote(File.pathSeparator), 2)[0];
            addDataCandidate(candidates, Path.of(firstClassPathEntry).toAbsolutePath().normalize());
        }

        try {
            Path codeLocation = Path.of(CatalogueApplication.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();
            addDataCandidate(candidates, codeLocation);
        } catch (URISyntaxException | NullPointerException exception) {
            // Use the Java class path and current directory as fallbacks.
        }
        candidates.add(Path.of("").toAbsolutePath().normalize().resolve("data"));

        for (Path candidate : candidates) {
            if (Files.isRegularFile(candidate.resolve("cours.json"))
                    && Files.isRegularFile(candidate.resolve("resultats.json"))) {
                return candidate;
            }
        }
        throw new IOException("Fichiers data/cours.json et data/resultats.json introuvables.");
    }

    private void addDataCandidate(List<Path> candidates, Path runtimeLocation) {
        Path baseDirectory = Files.isDirectory(runtimeLocation)
                ? runtimeLocation
                : runtimeLocation.getParent();
        if (baseDirectory != null) {
            candidates.add(baseDirectory.resolve("data"));
        }
    }

    private JsonNode readJsonArray(Path file) throws IOException {
        String content = Files.readString(file, StandardCharsets.UTF_8);
        try {
            JsonNode root = objectMapper.readTree(content);
            if (root == null || !root.isArray()) {
                throw new IOException("Le fichier " + file.getFileName() + " doit contenir une liste JSON.");
            }
            return root;
        } catch (JsonProcessingException exception) {
            throw new IOException("JSON invalide dans " + file.getFileName() + ".", exception);
        }
    }

    private ObjectNode normalizeCourse(JsonNode row) throws IOException {
        if (!row.isObject()
                || !row.path("id").canConvertToInt()
                || !row.path("titre").isTextual()
                || !row.path("description").isTextual()
                || !row.path("categorie").isTextual()
                || !row.path("auteur").isTextual()) {
            throw new IOException("Format de cours invalide.");
        }

        ObjectNode course = objectMapper.createObjectNode();
        course.put("id", row.path("id").intValue());
        course.put("titre", row.path("titre").textValue());
        course.put("description", row.path("description").textValue());
        course.put("categorie", row.path("categorie").textValue());
        course.put("auteur", row.path("auteur").textValue());
        return course;
    }

    private void writeCourses(List<ObjectNode> updatedCourses) throws IOException {
        ArrayNode array = objectMapper.createArrayNode();
        updatedCourses.forEach(array::add);
        byte[] json = objectMapper.writeValueAsBytes(array);

        Path temporaryFile = Files.createTempFile(dataDirectory, "cours-", ".tmp");
        boolean moved = false;
        try {
            Files.write(temporaryFile, json, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.move(temporaryFile, coursesFile, StandardCopyOption.REPLACE_EXISTING);
            moved = true;
        } finally {
            if (!moved) {
                Files.deleteIfExists(temporaryFile);
            }
        }
    }
}
