package com.technoworld.catalogue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Pattern;

@Component
public class UtilisateurStore {
    private static final int PASSWORD_ITERATIONS = 310_000;
    private static final int HASH_BITS = 256;
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    private final ObjectMapper objectMapper;
    private final CatalogueStore catalogueStore;
    private final SecureRandom secureRandom = new SecureRandom();
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final List<ObjectNode> users = new ArrayList<>();

    private Path usersFile;
    private int lastId;

    public UtilisateurStore(ObjectMapper objectMapper, CatalogueStore catalogueStore) {
        this.objectMapper = objectMapper;
        this.catalogueStore = catalogueStore;
    }

    @PostConstruct
    public void loadUsers() throws IOException {
        usersFile = catalogueStore.getDataDirectory().resolve("utilisateurs.json");
        if (!Files.exists(usersFile)) {
            writeUsers(List.of());
        } else {
            JsonNode data;
            try {
                data = objectMapper.readTree(Files.readString(usersFile, StandardCharsets.UTF_8));
            } catch (JsonProcessingException exception) {
                throw new IOException("JSON invalide dans utilisateurs.json.", exception);
            }
            if (data == null || !data.isArray()) {
                throw new IOException("Le fichier utilisateurs.json doit contenir une liste JSON.");
            }

            for (JsonNode row : data) {
                if (!row.isObject()
                        || !row.path("id").canConvertToInt()
                        || !row.path("nom").isTextual()
                        || !row.path("email").isTextual()
                        || !row.path("role").isTextual()
                        || !row.path("sel_mot_de_passe").isTextual()
                        || !row.path("hash_mot_de_passe").isTextual()) {
                    throw new IOException("Format d'utilisateur invalide.");
                }
                ObjectNode user = ((ObjectNode) row).deepCopy();
                users.add(user);
                lastId = Math.max(lastId, user.path("id").intValue());
            }
        }
        bootstrapAdministrator();
    }

    public ObjectNode register(String name, String email, char[] password) throws IOException {
        lock.writeLock().lock();
        try {
            String normalizedEmail = normalizeEmail(email);
            if (users.stream().anyMatch(user -> normalizedEmail.equals(user.path("email").textValue()))) {
                throw new CatalogueApiException(409, "Cette adresse courriel est déjà utilisée.");
            }

            byte[] salt = new byte[16];
            secureRandom.nextBytes(salt);
            String encodedSalt = Base64.getEncoder().encodeToString(salt);
            String encodedHash = hashPassword(password, salt);

            ObjectNode user = objectMapper.createObjectNode();
            user.put("id", lastId + 1);
            user.put("nom", name.trim());
            user.put("email", normalizedEmail);
            user.put("role", "apprenant");
            user.put("sel_mot_de_passe", encodedSalt);
            user.put("hash_mot_de_passe", encodedHash);

            List<ObjectNode> updatedUsers = new ArrayList<>(users);
            updatedUsers.add(user);
            writeUsers(updatedUsers);
            users.clear();
            users.addAll(updatedUsers);
            lastId++;
            return publicUser(user);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode authenticate(String email, char[] password) {
        lock.readLock().lock();
        try {
            String normalizedEmail = normalizeEmail(email);
            for (ObjectNode user : users) {
                if (!normalizedEmail.equals(user.path("email").textValue())) {
                    continue;
                }

                byte[] salt = Base64.getDecoder().decode(user.path("sel_mot_de_passe").textValue());
                byte[] expected = Base64.getDecoder().decode(user.path("hash_mot_de_passe").textValue());
                byte[] actual = Base64.getDecoder().decode(hashPassword(password, salt));
                if (MessageDigest.isEqual(expected, actual)) {
                    return publicUser(user);
                }
                break;
            }
            throw new CatalogueApiException(401, "Identifiants invalides.");
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode findPublicUser(int userId) {
        lock.readLock().lock();
        try {
            for (ObjectNode user : users) {
                if (user.path("id").intValue() == userId) {
                    return publicUser(user);
                }
            }
            return null;
        } finally {
            lock.readLock().unlock();
        }
    }

    public List<ObjectNode> listPublicUsers() {
        lock.readLock().lock();
        try {
            List<ObjectNode> result = new ArrayList<>(users.size());
            users.forEach(user -> result.add(publicUser(user)));
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode createManagedUser(String name, String email, char[] password, String role)
            throws IOException {
        lock.writeLock().lock();
        try {
            if (!isManagedRole(role)) {
                throw new CatalogueApiException(400, "Rôle utilisateur invalide.");
            }
            String normalizedEmail = normalizeEmail(email);
            if (findByEmail(normalizedEmail) != null) {
                throw new CatalogueApiException(409, "Cette adresse courriel est déjà utilisée.");
            }
            ObjectNode user = newUser(name, normalizedEmail, password, role);
            List<ObjectNode> updatedUsers = new ArrayList<>(users);
            updatedUsers.add(user);
            writeUsers(updatedUsers);
            users.clear();
            users.addAll(updatedUsers);
            lastId++;
            return publicUser(user);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode updateManagedUser(
            int userId, String name, String email, String role, char[] password) throws IOException {
        lock.writeLock().lock();
        try {
            int index = indexOfUser(userId);
            if (index < 0) {
                throw new CatalogueApiException(404, "Utilisateur introuvable.");
            }
            ObjectNode user = users.get(index).deepCopy();
            if (name != null) {
                user.put("nom", name.trim());
            }
            if (email != null) {
                String normalizedEmail = normalizeEmail(email);
                ObjectNode existing = findByEmail(normalizedEmail);
                if (existing != null && existing.path("id").intValue() != userId) {
                    throw new CatalogueApiException(409, "Cette adresse courriel est déjà utilisée.");
                }
                user.put("email", normalizedEmail);
            }
            if (role != null) {
                if (!isManagedRole(role)) {
                    throw new CatalogueApiException(400, "Rôle utilisateur invalide.");
                }
                if ("administrateur".equals(user.path("role").textValue())
                        && !"administrateur".equals(role)
                        && administratorCount() == 1) {
                    throw new CatalogueApiException(409, "Le dernier administrateur ne peut pas être rétrogradé.");
                }
                user.put("role", role);
            }
            if (password != null) {
                setPassword(user, password);
            }

            List<ObjectNode> updatedUsers = new ArrayList<>(users);
            updatedUsers.set(index, user);
            writeUsers(updatedUsers);
            users.clear();
            users.addAll(updatedUsers);
            return publicUser(user);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void deleteManagedUser(int userId) throws IOException {
        lock.writeLock().lock();
        try {
            int index = indexOfUser(userId);
            if (index < 0) {
                throw new CatalogueApiException(404, "Utilisateur introuvable.");
            }
            if ("administrateur".equals(users.get(index).path("role").textValue())
                    && administratorCount() == 1) {
                throw new CatalogueApiException(409, "Le dernier administrateur ne peut pas être supprimé.");
            }
            List<ObjectNode> updatedUsers = new ArrayList<>(users);
            updatedUsers.remove(index);
            writeUsers(updatedUsers);
            users.clear();
            users.addAll(updatedUsers);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private ObjectNode publicUser(ObjectNode user) {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("id", user.path("id").intValue());
        result.put("nom", user.path("nom").textValue());
        result.put("email", user.path("email").textValue());
        result.put("role", user.path("role").textValue());
        return result;
    }

    private String normalizeEmail(String email) {
        return email.trim().toLowerCase(Locale.ROOT);
    }

    private ObjectNode newUser(String name, String email, char[] password, String role) {
        ObjectNode user = objectMapper.createObjectNode();
        user.put("id", lastId + 1);
        user.put("nom", name.trim());
        user.put("email", email);
        user.put("role", role);
        setPassword(user, password);
        return user;
    }

    private void setPassword(ObjectNode user, char[] password) {
        byte[] salt = new byte[16];
        secureRandom.nextBytes(salt);
        user.put("sel_mot_de_passe", Base64.getEncoder().encodeToString(salt));
        user.put("hash_mot_de_passe", hashPassword(password, salt));
    }

    private ObjectNode findByEmail(String email) {
        for (ObjectNode user : users) {
            if (email.equals(user.path("email").textValue())) {
                return user;
            }
        }
        return null;
    }

    private int indexOfUser(int userId) {
        for (int index = 0; index < users.size(); index++) {
            if (users.get(index).path("id").intValue() == userId) {
                return index;
            }
        }
        return -1;
    }

    private long administratorCount() {
        return users.stream().filter(user -> "administrateur".equals(user.path("role").textValue())).count();
    }

    private boolean isManagedRole(String role) {
        return "apprenant".equals(role) || "enseignant".equals(role) || "administrateur".equals(role);
    }

    private void bootstrapAdministrator() throws IOException {
        String email = System.getenv("TECHNOWORLD_ADMIN_EMAIL");
        String passwordValue = System.getenv("TECHNOWORLD_ADMIN_PASSWORD");
        if ((email == null || email.isBlank()) && (passwordValue == null || passwordValue.isBlank())) {
            return;
        }
        if (email == null || email.isBlank() || passwordValue == null || passwordValue.length() < 12) {
            throw new IOException("Configurez TECHNOWORLD_ADMIN_EMAIL et TECHNOWORLD_ADMIN_PASSWORD (12 caractères minimum).");
        }
        if (email.length() > 254 || !EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new IOException("TECHNOWORLD_ADMIN_EMAIL doit être une adresse courriel valide.");
        }
        if (administratorCount() > 0) {
            return;
        }

        String normalizedEmail = normalizeEmail(email);
        ObjectNode existing = findByEmail(normalizedEmail);
        char[] password = passwordValue.toCharArray();
        try {
            if (existing != null) {
                ObjectNode updatedUser = existing.deepCopy();
                updatedUser.put("role", "administrateur");
                setPassword(updatedUser, password);
                List<ObjectNode> updatedUsers = new ArrayList<>(users);
                updatedUsers.set(indexOfUser(updatedUser.path("id").intValue()), updatedUser);
                writeUsers(updatedUsers);
                users.clear();
                users.addAll(updatedUsers);
                return;
            }
            ObjectNode admin = newUser("Administrateur", normalizedEmail, password, "administrateur");
            List<ObjectNode> updatedUsers = new ArrayList<>(users);
            updatedUsers.add(admin);
            writeUsers(updatedUsers);
            users.clear();
            users.addAll(updatedUsers);
            lastId++;
        } finally {
            java.util.Arrays.fill(password, '\0');
        }
    }

    private String hashPassword(char[] password, byte[] salt) {
        PBEKeySpec specification = new PBEKeySpec(password, salt, PASSWORD_ITERATIONS, HASH_BITS);
        try {
            byte[] hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(specification)
                    .getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("Impossible de vérifier le mot de passe.", exception);
        } finally {
            specification.clearPassword();
        }
    }

    private void writeUsers(List<ObjectNode> updatedUsers) throws IOException {
        ArrayNode array = objectMapper.createArrayNode();
        updatedUsers.forEach(array::add);
        byte[] json = objectMapper.writeValueAsBytes(array);

        Path temporaryFile = Files.createTempFile(usersFile.getParent(), "utilisateurs-", ".tmp");
        boolean moved = false;
        try {
            Files.write(temporaryFile, json, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.move(temporaryFile, usersFile, StandardCopyOption.REPLACE_EXISTING);
            moved = true;
        } finally {
            if (!moved) {
                Files.deleteIfExists(temporaryFile);
            }
        }
    }
}
