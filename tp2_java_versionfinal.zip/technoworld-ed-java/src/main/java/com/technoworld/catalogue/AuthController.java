package com.technoworld.catalogue;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.regex.Pattern;

@RestController
public class AuthController {
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final int MAX_NAME_LENGTH = 100;
    private static final int MIN_PASSWORD_LENGTH = 8;
    private static final int MAX_PASSWORD_LENGTH = 128;

    private final UtilisateurStore userStore;
    private final ObjectMapper objectMapper;

    public AuthController(UtilisateurStore userStore, ObjectMapper objectMapper) {
        this.userStore = userStore;
        this.objectMapper = objectMapper;
    }

    @PostMapping("/api/auth/inscription")
    public ResponseEntity<ObjectNode> register(
            @RequestBody JsonNode body,
            HttpServletRequest request) throws IOException {
        String name = requiredText(body, "nom");
        String email = requiredText(body, "email");
        char[] password = password(body);
        try {
            validateName(name);
            validateEmail(email);
            validateRegistrationPassword(password);
            ObjectNode user = userStore.register(name, email, password);
            startSession(request, user.path("id").intValue());
            return success(HttpStatus.CREATED, user);
        } finally {
            java.util.Arrays.fill(password, '\0');
        }
    }

    @PostMapping("/api/auth/connexion")
    public ResponseEntity<ObjectNode> login(
            @RequestBody JsonNode body,
            HttpServletRequest request) {
        String email = requiredText(body, "email");
        char[] password = password(body);
        try {
            validateEmail(email);
            validateLoginCredentialLength(password);
            ObjectNode user = userStore.authenticate(email, password);
            startSession(request, user.path("id").intValue());
            return success(HttpStatus.OK, user);
        } finally {
            java.util.Arrays.fill(password, '\0');
        }
    }

    @GetMapping("/api/auth/session")
    public ResponseEntity<ObjectNode> session(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || !(session.getAttribute("userId") instanceof Integer userId)) {
            throw new CatalogueApiException(401, "Aucune session active.");
        }
        ObjectNode user = userStore.findPublicUser(userId);
        if (user == null) {
            session.invalidate();
            throw new CatalogueApiException(401, "Aucune session active.");
        }
        return success(HttpStatus.OK, user);
    }

    @PostMapping("/api/auth/deconnexion")
    public ResponseEntity<ObjectNode> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        ObjectNode data = objectMapper.createObjectNode();
        data.put("message", "Déconnexion réussie.");
        return success(HttpStatus.OK, data);
    }

    @ExceptionHandler(CatalogueApiException.class)
    public ResponseEntity<ObjectNode> handleApiError(CatalogueApiException exception) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", false);
        body.put("message", exception.getMessage());
        return ResponseEntity.status(exception.getStatus()).body(body);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ObjectNode> handleInvalidJson() {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", false);
        body.put("message", "Corps JSON illisible.");
        return ResponseEntity.badRequest().body(body);
    }

    private ResponseEntity<ObjectNode> success(HttpStatus status, JsonNode data) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", true);
        body.set("data", data);
        return ResponseEntity.status(status).body(body);
    }

    private String requiredText(JsonNode body, String field) {
        JsonNode value = body == null ? null : body.get(field);
        if (value == null || !value.isTextual() || value.textValue().trim().isEmpty()) {
            throw new CatalogueApiException(400, "Champs d’inscription ou de connexion invalides.");
        }
        return value.textValue();
    }

    private char[] password(JsonNode body) {
        JsonNode value = body == null ? null : body.get("motDePasse");
        if (value == null || !value.isTextual()) {
            throw new CatalogueApiException(400, "Champs d’inscription ou de connexion invalides.");
        }
        return value.textValue().toCharArray();
    }

    private void validateName(String name) {
        int length = name.trim().codePointCount(0, name.trim().length());
        if (length == 0 || length > MAX_NAME_LENGTH) {
            throw new CatalogueApiException(400, "Le nom doit contenir entre 1 et 100 caractères.");
        }
    }

    private void validateEmail(String email) {
        if (email.length() > 254 || !EMAIL_PATTERN.matcher(email.trim()).matches()) {
            throw new CatalogueApiException(400, "Adresse courriel invalide.");
        }
    }

    private void validateRegistrationPassword(char[] password) {
        if (password.length < MIN_PASSWORD_LENGTH || password.length > MAX_PASSWORD_LENGTH) {
            throw new CatalogueApiException(400, "Le mot de passe doit contenir entre 8 et 128 caractères.");
        }
    }

    private void validateLoginCredentialLength(char[] password) {
        if (password.length > MAX_PASSWORD_LENGTH) {
            throw new CatalogueApiException(401, "Identifiants invalides.");
        }
    }

    private void startSession(HttpServletRequest request, int userId) {
        HttpSession previousSession = request.getSession(false);
        if (previousSession != null) {
            previousSession.invalidate();
        }
        HttpSession session = request.getSession(true);
        session.setMaxInactiveInterval(30 * 60);
        session.setAttribute("userId", userId);
    }
}
