package com.technoworld.catalogue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
public class CatalogueController {
    private static final Pattern AVERAGE_PATH = Pattern.compile("^/cours/([^/]+)/moyenne$");
    private static final Pattern ASCII_DIGITS = Pattern.compile("^[0-9]+$");

    private final CatalogueStore store;
    private final LearningStore learningStore;
    private final UtilisateurStore userStore;
    private final ObjectMapper objectMapper;

    public CatalogueController(
            CatalogueStore store, LearningStore learningStore, UtilisateurStore userStore, ObjectMapper objectMapper) {
        this.store = store;
        this.learningStore = learningStore;
        this.userStore = userStore;
        this.objectMapper = objectMapper;
    }

    @RequestMapping("/**")
    public void dispatch(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            String path = request.getRequestURI();
            String method = request.getMethod();

            if ("/cours/recherche".equals(path)) {
                requireMethod(method, "GET");
                String query = queryParameter(request, "q");
                if (query == null || query.isEmpty()) {
                    throw new CatalogueApiException(400, "Le terme de recherche est obligatoire.");
                }
                writeSuccess(response, 200, store.searchCourses(query));
                return;
            }

            if ("/cours".equals(path)) {
                if ("POST".equals(method)) {
                    createCourse(request, response);
                    return;
                }
                if ("GET".equals(method)) {
                    String pageValue = queryParameter(request, "page");
                    long page = pageValue == null ? 1 : parsePage(pageValue);
                    writeSuccess(response, 200, store.listCourses(page));
                    return;
                }
                throw new CatalogueApiException(405, "Méthode non autorisée.");
            }

            Matcher averagePath = AVERAGE_PATH.matcher(path);
            if (averagePath.matches()) {
                requireMethod(method, "GET");
                int courseId = parseId(averagePath.group(1));
                writeSuccess(response, 200, store.averageForCourse(courseId));
                return;
            }

            throw new CatalogueApiException(404, "Route introuvable.");
        } catch (CatalogueApiException exception) {
            writeError(response, exception.getStatus(), exception.getMessage());
        } catch (Exception exception) {
            writeError(response, 500, "Erreur interne.");
        }
    }

    private void createCourse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String rawBody = new String(request.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        JsonNode body;
        try {
            body = objectMapper.readTree(rawBody);
        } catch (JsonProcessingException exception) {
            throw new CatalogueApiException(400, "Corps JSON illisible.");
        }

        if (body == null) {
            throw new CatalogueApiException(400, "Corps JSON illisible.");
        }
        if (!body.isObject()) {
            throw new CatalogueApiException(400, "Corps JSON invalide.");
        }

        String title = requiredText(body, "titre");
        String description = requiredText(body, "description");
        String category = requiredText(body, "categorie");
        HttpSession session = request.getSession(false);
        if (session == null || !(session.getAttribute("userId") instanceof Integer userId)) {
            throw new CatalogueApiException(401, "Connexion enseignant requise.");
        }
        ObjectNode user = userStore.findPublicUser(userId);
        if (user == null || !"enseignant".equals(user.path("role").asText())) {
            throw new CatalogueApiException(403, "Seul un enseignant peut proposer un cours.");
        }
        ObjectNode course = learningStore.createTeacherCourse(userId, user.path("nom").asText(),
                title, description, category);
        writeSuccess(response, 201, course);
    }

    private String requiredText(JsonNode body, String field) {
        JsonNode value = body.get(field);
        if (value == null
                || !value.isTextual()
                || value.textValue().trim().isEmpty()
                || value.textValue().codePointCount(0, value.textValue().length()) > 100) {
            throw new CatalogueApiException(400, "Champs du cours invalides.");
        }
        return value.textValue();
    }

    private String queryParameter(HttpServletRequest request, String name) {
        String[] values = request.getParameterValues(name);
        return values == null || values.length == 0 ? null : values[values.length - 1];
    }

    private long parsePage(String value) {
        if (!ASCII_DIGITS.matcher(value).matches()) {
            throw new CatalogueApiException(400, "Page invalide.");
        }
        String normalized = value.replaceFirst("^0+(?!$)", "");
        try {
            long page = Long.parseLong(normalized);
            if (page < 1) {
                throw new CatalogueApiException(400, "Page invalide.");
            }
            return page;
        } catch (NumberFormatException exception) {
            throw new CatalogueApiException(400, "Page invalide.");
        }
    }

    private int parseId(String value) {
        if (!ASCII_DIGITS.matcher(value).matches()) {
            throw new CatalogueApiException(400, "Identifiant invalide.");
        }
        String normalized = value.replaceFirst("^0+(?!$)", "");
        try {
            return Integer.parseInt(normalized);
        } catch (NumberFormatException exception) {
            throw new CatalogueApiException(400, "Identifiant invalide.");
        }
    }

    private void requireMethod(String actual, String expected) {
        if (!expected.equals(actual)) {
            throw new CatalogueApiException(405, "Méthode non autorisée.");
        }
    }

    private void writeSuccess(HttpServletResponse response, int status, JsonNode data) throws IOException {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", true);
        body.set("data", data);
        writeJson(response, status, body);
    }

    private void writeError(HttpServletResponse response, int status, String message) throws IOException {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", false);
        body.put("message", message);
        writeJson(response, status, body);
    }

    private void writeJson(HttpServletResponse response, int status, JsonNode body) throws IOException {
        response.setStatus(status);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json; charset=utf-8");
        objectMapper.writeValue(response.getOutputStream(), body);
    }
}
