package com.technoworld.catalogue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Component
public class LearningStore {
    private final ObjectMapper objectMapper;
    private final CatalogueStore catalogueStore;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    private ObjectNode state;
    private Path stateFile;

    public LearningStore(ObjectMapper objectMapper, CatalogueStore catalogueStore) {
        this.objectMapper = objectMapper;
        this.catalogueStore = catalogueStore;
    }

    @PostConstruct
    public void load() throws IOException {
        stateFile = catalogueStore.getDataDirectory().resolve("plateforme.json");
        if (!Files.exists(stateFile)) {
            state = newState();
            persist(state);
            return;
        }
        try {
            JsonNode root = objectMapper.readTree(Files.readString(stateFile, StandardCharsets.UTF_8));
            if (root == null || !root.isObject()) {
                throw new IOException("Le fichier plateforme.json doit contenir un objet JSON.");
            }
            state = ((ObjectNode) root).deepCopy();
            for (String field : List.of("categories", "cours", "lecons", "inscriptions", "quiz", "tentatives", "alias_categories")) {
                if (!state.path(field).isArray()) {
                    throw new IOException("Format invalide pour " + field + " dans plateforme.json.");
                }
            }
        } catch (JsonProcessingException exception) {
            throw new IOException("JSON invalide dans plateforme.json.", exception);
        }
    }

    public ArrayNode listCategories() {
        lock.readLock().lock();
        try {
            return ((ArrayNode) state.path("categories")).deepCopy();
        } finally {
            lock.readLock().unlock();
        }
    }

    public ArrayNode listPublishedCourses(String category, String query) {
        lock.readLock().lock();
        try {
            ArrayNode result = objectMapper.createArrayNode();
            String normalizedQuery = query == null ? "" : query.toLowerCase(Locale.ROOT);
            for (ObjectNode course : catalogueStore.allCourses()) {
                if (matches(course, category, normalizedQuery)) {
                    ObjectNode item = publicLegacyCourse(course);
                    result.add(item);
                }
            }
            for (JsonNode row : state.path("cours")) {
                if (row.path("statut").asText().equals("publie")
                        && matches(row, category, normalizedQuery)) {
                    result.add(publicPlatformCourse((ObjectNode) row));
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode courseDetails(String courseId, Integer userId, String role) {
        lock.readLock().lock();
        try {
            ObjectNode course = findCourse(courseId);
            if (course == null || !"publie".equals(course.path("statut").asText())) {
                throw new CatalogueApiException(404, "Cours introuvable.");
            }
            ObjectNode detail = course.deepCopy();
            boolean hasAccess = userId != null
                    && (hasEnrollment(userId, courseId)
                    || ("enseignant".equals(role) && ownsCourse(userId, courseId))
                    || "administrateur".equals(role));
            ArrayNode lessons = objectMapper.createArrayNode();
            if (hasAccess) {
                for (JsonNode lesson : state.path("lecons")) {
                    if (courseId.equals(lesson.path("cours_id").asText())) {
                        lessons.add(lesson);
                    }
                }
            }
            detail.set("lecons", lessons);
            detail.put("acces_necessaire", !hasAccess);
            return detail;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode createTeacherCourse(
            int teacherId, String author, String title, String description, String category) throws IOException {
        lock.writeLock().lock();
        try {
            requireCategory(category);
            if (titleExists(title)) {
                throw new CatalogueApiException(409, "Ce titre existe déjà.");
            }
            ObjectNode updated = state.deepCopy();
            int id = updated.path("prochain_cours_id").asInt(1);
            updated.put("prochain_cours_id", id + 1);
            ObjectNode course = objectMapper.createObjectNode();
            course.put("id", "proposed-" + id);
            course.put("titre", title.trim());
            course.put("description", description.trim());
            course.put("categorie", category);
            course.put("auteur", author);
            course.put("enseignant_id", teacherId);
            course.put("statut", "en_attente");
            course.put("date_creation", Instant.now().toString());
            array(updated, "cours").add(course);
            save(updated);
            return publicPlatformCourse(course);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ArrayNode listTeacherCourses(int teacherId) {
        lock.readLock().lock();
        try {
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode row : state.path("cours")) {
                if (row.path("enseignant_id").asInt() == teacherId) {
                    result.add(publicPlatformCourse((ObjectNode) row));
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode updateTeacherCourse(
            int teacherId, String courseId, String title, String description, String category) throws IOException {
        lock.writeLock().lock();
        try {
            requireCategory(category);
            ObjectNode updated = state.deepCopy();
            ObjectNode course = requireOwnedCourse(updated, teacherId, courseId);
            if (!course.path("titre").asText().equals(title.trim()) && titleExists(title, courseId)) {
                throw new CatalogueApiException(409, "Ce titre existe déjà.");
            }
            course.put("titre", title.trim());
            course.put("description", description.trim());
            course.put("categorie", category);
            course.put("statut", "en_attente");
            save(updated);
            return publicPlatformCourse(course);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void deleteTeacherCourse(int teacherId, String courseId) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            removeWhere(array(updated, "cours"), item -> courseId.equals(item.path("id").asText()));
            removeWhere(array(updated, "lecons"), item -> courseId.equals(item.path("cours_id").asText()));
            removeWhere(array(updated, "inscriptions"), item -> courseId.equals(item.path("cours_id").asText()));
            removeWhere(array(updated, "quiz"), item -> courseId.equals(item.path("cours_id").asText()));
            removeWhere(array(updated, "tentatives"), item -> courseId.equals(item.path("cours_id").asText()));
            save(updated);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ArrayNode listCourseLessons(int teacherId, String courseId) {
        lock.readLock().lock();
        try {
            requireOwnedCourse(state, teacherId, courseId);
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode lesson : state.path("lecons")) {
                if (courseId.equals(lesson.path("cours_id").asText())) {
                    result.add(lesson);
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode createLesson(int teacherId, String courseId, String title, String content) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            int id = updated.path("prochaine_lecon_id").asInt(1);
            updated.put("prochaine_lecon_id", id + 1);
            ObjectNode lesson = objectMapper.createObjectNode();
            lesson.put("id", "lesson-" + id);
            lesson.put("cours_id", courseId);
            lesson.put("titre", title.trim());
            lesson.put("contenu", content.trim());
            lesson.put("ordre", id);
            array(updated, "lecons").add(lesson);
            save(updated);
            return lesson;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode updateLesson(int teacherId, String courseId, String lessonId, String title, String content)
            throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            ObjectNode lesson = findById(array(updated, "lecons"), lessonId);
            if (lesson == null || !courseId.equals(lesson.path("cours_id").asText())) {
                throw new CatalogueApiException(404, "Leçon introuvable.");
            }
            lesson.put("titre", title.trim());
            lesson.put("contenu", content.trim());
            save(updated);
            return lesson;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void deleteLesson(int teacherId, String courseId, String lessonId) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            ObjectNode lesson = findById(array(updated, "lecons"), lessonId);
            if (lesson == null || !courseId.equals(lesson.path("cours_id").asText())) {
                throw new CatalogueApiException(404, "Leçon introuvable.");
            }
            removeWhere(array(updated, "lecons"), item -> lessonId.equals(item.path("id").asText()));
            for (JsonNode enrollment : array(updated, "inscriptions")) {
                ArrayNode completed = (ArrayNode) enrollment.path("lecons_terminees");
                removeWhere(completed, item -> lessonId.equals(item.asText()));
            }
            save(updated);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ArrayNode pendingCourses() {
        lock.readLock().lock();
        try {
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode course : state.path("cours")) {
                if ("en_attente".equals(course.path("statut").asText())) {
                    result.add(publicPlatformCourse((ObjectNode) course));
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode decideCourse(String courseId, boolean approved, String reason) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            ObjectNode course = findById(array(updated, "cours"), courseId);
            if (course == null || !"en_attente".equals(course.path("statut").asText())) {
                throw new CatalogueApiException(404, "Proposition de cours introuvable.");
            }
            course.put("statut", approved ? "publie" : "refuse");
            course.put("motif_refus", approved ? "" : reason.trim());
            course.put("date_decision", Instant.now().toString());
            save(updated);
            return publicPlatformCourse(course);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode enroll(int userId, String courseId) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode course = findCourse(courseId);
            if (course == null || !"publie".equals(course.path("statut").asText())) {
                throw new CatalogueApiException(404, "Cours publié introuvable.");
            }
            if (hasEnrollment(userId, courseId)) {
                throw new CatalogueApiException(409, "Vous êtes déjà inscrit à ce cours.");
            }
            ObjectNode updated = state.deepCopy();
            ObjectNode enrollment = objectMapper.createObjectNode();
            enrollment.put("utilisateur_id", userId);
            enrollment.put("cours_id", courseId);
            enrollment.set("lecons_terminees", objectMapper.createArrayNode());
            enrollment.put("date_inscription", Instant.now().toString());
            array(updated, "inscriptions").add(enrollment);
            save(updated);
            return progressSummary(enrollment, course);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ArrayNode learnerCourses(int userId) {
        lock.readLock().lock();
        try {
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode enrollment : state.path("inscriptions")) {
                if (enrollment.path("utilisateur_id").asInt() == userId) {
                    ObjectNode course = findCourse(enrollment.path("cours_id").asText());
                    if (course != null) {
                        result.add(progressSummary((ObjectNode) enrollment, course));
                    }
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode markLessonComplete(int userId, String courseId, String lessonId) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            ObjectNode enrollment = findEnrollment(updated, userId, courseId);
            if (enrollment == null) {
                throw new CatalogueApiException(403, "Inscrivez-vous au cours pour suivre votre progression.");
            }
            ObjectNode lesson = findById(array(updated, "lecons"), lessonId);
            if (lesson == null || !courseId.equals(lesson.path("cours_id").asText())) {
                throw new CatalogueApiException(404, "Leçon introuvable.");
            }
            ArrayNode completed = array(enrollment, "lecons_terminees");
            boolean alreadyCompleted = false;
            for (JsonNode item : completed) {
                alreadyCompleted |= lessonId.equals(item.asText());
            }
            if (!alreadyCompleted) {
                completed.add(lessonId);
            }
            save(updated);
            return progressSummary(enrollment, findCourse(courseId));
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ArrayNode quizzesForLearner(int userId, String courseId) {
        lock.readLock().lock();
        try {
            requireEnrollment(userId, courseId);
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode quiz : state.path("quiz")) {
                if (courseId.equals(quiz.path("cours_id").asText())) {
                    result.add(publicQuiz((ObjectNode) quiz, false));
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ArrayNode quizzesForTeacher(int teacherId, String courseId) {
        lock.readLock().lock();
        try {
            requireOwnedCourse(state, teacherId, courseId);
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode quiz : state.path("quiz")) {
                if (courseId.equals(quiz.path("cours_id").asText())) {
                    result.add(publicQuiz((ObjectNode) quiz, true));
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode createQuiz(int teacherId, String courseId, String title, JsonNode questions)
            throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            int quizNumber = updated.path("prochain_quiz_id").asInt(1);
            updated.put("prochain_quiz_id", quizNumber + 1);
            ObjectNode quiz = objectMapper.createObjectNode();
            quiz.put("id", "quiz-" + quizNumber);
            quiz.put("cours_id", courseId);
            quiz.put("titre", title.trim());
            ArrayNode storedQuestions = objectMapper.createArrayNode();
            int questionNumber = updated.path("prochaine_question_id").asInt(1);
            for (JsonNode question : questions) {
                ObjectNode stored = objectMapper.createObjectNode();
                stored.put("id", "question-" + questionNumber);
                stored.put("texte", question.path("texte").asText().trim());
                stored.set("options", question.path("options").deepCopy());
                stored.put("bonne_reponse", question.path("bonneReponse").intValue());
                storedQuestions.add(stored);
                questionNumber++;
            }
            updated.put("prochaine_question_id", questionNumber);
            quiz.set("questions", storedQuestions);
            array(updated, "quiz").add(quiz);
            save(updated);
            return publicQuiz(quiz, true);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode updateQuiz(int teacherId, String courseId, String quizId, String title, JsonNode questions)
            throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            ObjectNode quiz = findById(array(updated, "quiz"), quizId);
            if (quiz == null || !courseId.equals(quiz.path("cours_id").asText())) {
                throw new CatalogueApiException(404, "Quiz introuvable.");
            }
            quiz.put("titre", title.trim());
            ArrayNode storedQuestions = objectMapper.createArrayNode();
            int questionNumber = updated.path("prochaine_question_id").asInt(1);
            for (JsonNode question : questions) {
                ObjectNode stored = objectMapper.createObjectNode();
                stored.put("id", "question-" + questionNumber);
                stored.put("texte", question.path("texte").asText().trim());
                stored.set("options", question.path("options").deepCopy());
                stored.put("bonne_reponse", question.path("bonneReponse").intValue());
                storedQuestions.add(stored);
                questionNumber++;
            }
            updated.put("prochaine_question_id", questionNumber);
            quiz.set("questions", storedQuestions);
            save(updated);
            return publicQuiz(quiz, true);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void deleteQuiz(int teacherId, String courseId, String quizId) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            requireOwnedCourse(updated, teacherId, courseId);
            ObjectNode quiz = findById(array(updated, "quiz"), quizId);
            if (quiz == null || !courseId.equals(quiz.path("cours_id").asText())) {
                throw new CatalogueApiException(404, "Quiz introuvable.");
            }
            removeWhere(array(updated, "quiz"), item -> quizId.equals(item.path("id").asText()));
            removeWhere(array(updated, "tentatives"), item -> quizId.equals(item.path("quiz_id").asText()));
            save(updated);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode submitQuiz(int userId, String courseId, String quizId, JsonNode answers) throws IOException {
        lock.writeLock().lock();
        try {
            requireEnrollment(userId, courseId);
            ObjectNode quiz = findById(array(state, "quiz"), quizId);
            if (quiz == null || !courseId.equals(quiz.path("cours_id").asText())) {
                throw new CatalogueApiException(404, "Quiz introuvable.");
            }
            ArrayNode questions = array(quiz, "questions");
            if (questions.isEmpty()) {
                throw new CatalogueApiException(409, "Ce quiz ne contient aucune question.");
            }
            int correct = 0;
            for (JsonNode question : questions) {
                JsonNode answer = answers.get(question.path("id").asText());
                if (answer != null && answer.canConvertToInt()
                        && answer.intValue() == question.path("bonne_reponse").intValue()) {
                    correct++;
                }
            }
            double score = Math.round(correct * 10000.0 / questions.size()) / 100.0;
            ObjectNode updated = state.deepCopy();
            int attemptNumber = updated.path("prochaine_tentative_id").asInt(1);
            updated.put("prochaine_tentative_id", attemptNumber + 1);
            ObjectNode attempt = objectMapper.createObjectNode();
            attempt.put("id", "attempt-" + attemptNumber);
            attempt.put("utilisateur_id", userId);
            attempt.put("cours_id", courseId);
            attempt.put("quiz_id", quizId);
            attempt.put("score", score);
            attempt.put("bonnes_reponses", correct);
            attempt.put("nombre_questions", questions.size());
            attempt.put("date", Instant.now().toString());
            array(updated, "tentatives").add(attempt);
            save(updated);
            return publicAttempt(attempt, quiz.path("titre").asText());
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ArrayNode learnerResults(int userId) {
        lock.readLock().lock();
        try {
            ArrayNode result = objectMapper.createArrayNode();
            for (JsonNode attempt : state.path("tentatives")) {
                if (attempt.path("utilisateur_id").asInt() == userId) {
                    ObjectNode quiz = findById(array(state, "quiz"), attempt.path("quiz_id").asText());
                    result.add(publicAttempt((ObjectNode) attempt, quiz == null ? "Quiz supprimé" : quiz.path("titre").asText()));
                }
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ArrayNode ranking() {
        lock.readLock().lock();
        try {
            ObjectNode totals = objectMapper.createObjectNode();
            for (JsonNode attempt : state.path("tentatives")) {
                String key = Integer.toString(attempt.path("utilisateur_id").asInt());
                ObjectNode total = (ObjectNode) totals.get(key);
                if (total == null) {
                    total = objectMapper.createObjectNode();
                    total.put("utilisateur_id", attempt.path("utilisateur_id").asInt());
                    total.put("somme", 0.0);
                    total.put("nombre", 0);
                    totals.set(key, total);
                }
                total.put("somme", total.path("somme").asDouble() + attempt.path("score").asDouble());
                total.put("nombre", total.path("nombre").asInt() + 1);
            }
            List<ObjectNode> rows = new ArrayList<>();
            totals.elements().forEachRemaining(row -> {
                int count = row.path("nombre").asInt();
                double average = count == 0 ? 0 : row.path("somme").asDouble() / count;
                ObjectNode result = objectMapper.createObjectNode();
                result.put("utilisateur_id", row.path("utilisateur_id").asInt());
                result.put("moyenne", Math.round(average * 100.0) / 100.0);
                result.put("nombre_quiz", count);
                rows.add(result);
            });
            rows.sort(Comparator.comparingDouble((ObjectNode row) -> row.path("moyenne").asDouble()).reversed()
                    .thenComparing(Comparator.comparingInt((ObjectNode row) -> row.path("nombre_quiz").asInt()).reversed()));
            ArrayNode result = objectMapper.createArrayNode();
            int position = 1;
            for (ObjectNode row : rows) {
                row.put("position", position++);
                result.add(row);
            }
            return result;
        } finally {
            lock.readLock().unlock();
        }
    }

    public ObjectNode createCategory(String name) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            for (JsonNode category : updated.path("categories")) {
                if (category.path("nom").asText().equalsIgnoreCase(name.trim())) {
                    throw new CatalogueApiException(409, "Cette catégorie existe déjà.");
                }
            }
            int id = updated.path("prochaine_categorie_id").asInt(4);
            updated.put("prochaine_categorie_id", id + 1);
            ObjectNode category = objectMapper.createObjectNode();
            category.put("id", id);
            category.put("nom", name.trim());
            array(updated, "categories").add(category);
            save(updated);
            return category;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public ObjectNode updateCategory(int categoryId, String name) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            ObjectNode category = findCategory(updated, categoryId);
            if (category == null) {
                throw new CatalogueApiException(404, "Catégorie introuvable.");
            }
            for (JsonNode item : updated.path("categories")) {
                if (item.path("id").asInt() != categoryId && item.path("nom").asText().equalsIgnoreCase(name.trim())) {
                    throw new CatalogueApiException(409, "Cette catégorie existe déjà.");
                }
            }
            String previousName = category.path("nom").asText();
            category.put("nom", name.trim());
            ObjectNode existingAlias = findByFrom(array(updated, "alias_categories"), previousName);
            if (existingAlias == null) {
                existingAlias = objectMapper.createObjectNode();
                existingAlias.put("de", previousName);
                array(updated, "alias_categories").add(existingAlias);
            }
            existingAlias.put("vers", name.trim());
            for (JsonNode alias : array(updated, "alias_categories")) {
                if (previousName.equals(alias.path("vers").asText())) {
                    ((ObjectNode) alias).put("vers", name.trim());
                }
            }
            save(updated);
            return category;
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void deleteCategory(int categoryId) throws IOException {
        lock.writeLock().lock();
        try {
            ObjectNode updated = state.deepCopy();
            ObjectNode category = findCategory(updated, categoryId);
            if (category == null) {
                throw new CatalogueApiException(404, "Catégorie introuvable.");
            }
            if (updated.path("categories").size() <= 1) {
                throw new CatalogueApiException(409, "La dernière catégorie ne peut pas être supprimée.");
            }
            String name = category.path("nom").asText();
            boolean usedByLegacy = catalogueStore.allCourses().stream()
                    .anyMatch(course -> name.equals(resolveCategory(course.path("categorie").asText())));
            boolean usedByNew = false;
            for (JsonNode course : updated.path("cours")) {
                usedByNew |= name.equals(resolveCategory(course.path("categorie").asText()));
            }
            if (usedByLegacy || usedByNew) {
                throw new CatalogueApiException(409, "Cette catégorie est utilisée par un cours.");
            }
            removeWhere(array(updated, "categories"), item -> item.path("id").asInt() == categoryId);
            save(updated);
        } finally {
            lock.writeLock().unlock();
        }
    }

    private ObjectNode newState() {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("prochain_cours_id", 1);
        result.put("prochaine_lecon_id", 1);
        result.put("prochain_quiz_id", 1);
        result.put("prochaine_question_id", 1);
        result.put("prochaine_tentative_id", 1);
        result.put("prochaine_categorie_id", 4);
        ArrayNode categories = objectMapper.createArrayNode();
        addCategory(categories, 1, "Informatique");
        addCategory(categories, 2, "Biomédecine");
        addCategory(categories, 3, "Bio-informatique");
        result.set("categories", categories);
        result.set("alias_categories", objectMapper.createArrayNode());
        for (String field : List.of("cours", "lecons", "inscriptions", "quiz", "tentatives")) {
            result.set(field, objectMapper.createArrayNode());
        }
        return result;
    }

    private void addCategory(ArrayNode categories, int id, String name) {
        ObjectNode item = objectMapper.createObjectNode();
        item.put("id", id);
        item.put("nom", name);
        categories.add(item);
    }

    private boolean matches(JsonNode course, String category, String query) {
        if (category != null && !category.isBlank()
                && !category.equals(resolveCategory(course.path("categorie").asText()))) {
            return false;
        }
        return query.isEmpty()
                || course.path("titre").asText().toLowerCase(Locale.ROOT).contains(query)
                || course.path("description").asText().toLowerCase(Locale.ROOT).contains(query);
    }

    private ObjectNode publicLegacyCourse(ObjectNode source) {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("id", "catalogue-" + source.path("id").asInt());
        result.put("titre", source.path("titre").asText());
        result.put("description", source.path("description").asText());
        result.put("categorie", resolveCategory(source.path("categorie").asText()));
        result.put("auteur", source.path("auteur").asText());
        result.put("statut", "publie");
        return result;
    }

    private ObjectNode publicPlatformCourse(ObjectNode source) {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("id", source.path("id").asText());
        result.put("titre", source.path("titre").asText());
        result.put("description", source.path("description").asText());
        result.put("categorie", resolveCategory(source.path("categorie").asText()));
        result.put("auteur", source.path("auteur").asText());
        result.put("statut", source.path("statut").asText());
        if (source.has("motif_refus")) {
            result.put("motif_refus", source.path("motif_refus").asText());
        }
        return result;
    }

    private ObjectNode findCourse(String courseId) {
        if (courseId != null && courseId.startsWith("catalogue-")) {
            String rawId = courseId.substring("catalogue-".length());
            for (ObjectNode course : catalogueStore.allCourses()) {
                if (Integer.toString(course.path("id").asInt()).equals(rawId)) {
                    return publicLegacyCourse(course);
                }
            }
            return null;
        }
        ObjectNode course = findById(array(state, "cours"), courseId);
        return course == null ? null : publicPlatformCourse(course);
    }

    private ObjectNode findStoredCourse(ObjectNode source, String courseId) {
        if (courseId != null && courseId.startsWith("proposed-")) {
            return findById(array(source, "cours"), courseId);
        }
        return null;
    }

    private boolean titleExists(String title) {
        return titleExists(title, null);
    }

    private boolean titleExists(String title, String ignoredCourseId) {
        String normalized = title.trim().toLowerCase(Locale.ROOT);
        for (ObjectNode course : catalogueStore.allCourses()) {
            if (normalized.equals(course.path("titre").asText().toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        for (JsonNode course : state.path("cours")) {
            if (!course.path("id").asText().equals(ignoredCourseId)
                    && normalized.equals(course.path("titre").asText().toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    private ObjectNode requireOwnedCourse(ObjectNode source, int teacherId, String courseId) {
        ObjectNode course = findStoredCourse(source, courseId);
        if (course == null) {
            throw new CatalogueApiException(404, "Cours introuvable.");
        }
        if (course.path("enseignant_id").asInt() != teacherId) {
            throw new CatalogueApiException(403, "Vous ne pouvez gérer que vos propres cours.");
        }
        return course;
    }

    private boolean ownsCourse(int teacherId, String courseId) {
        ObjectNode course = findStoredCourse(state, courseId);
        return course != null && course.path("enseignant_id").asInt() == teacherId;
    }

    private void requireCategory(String name) {
        for (JsonNode category : state.path("categories")) {
            if (category.path("nom").asText().equals(name)) {
                return;
            }
        }
        throw new CatalogueApiException(400, "Catégorie inconnue.");
    }

    private ObjectNode findCategory(ObjectNode source, int id) {
        for (JsonNode category : source.path("categories")) {
            if (category.path("id").asInt() == id) {
                return (ObjectNode) category;
            }
        }
        return null;
    }

    private ObjectNode findByFrom(ArrayNode aliases, String categoryName) {
        for (JsonNode alias : aliases) {
            if (categoryName.equals(alias.path("de").asText())) {
                return (ObjectNode) alias;
            }
        }
        return null;
    }

    private String resolveCategory(String categoryName) {
        String resolved = categoryName;
        for (int pass = 0; pass <= state.path("alias_categories").size(); pass++) {
            ObjectNode alias = findByFrom(array(state, "alias_categories"), resolved);
            if (alias == null || resolved.equals(alias.path("vers").asText())) {
                break;
            }
            resolved = alias.path("vers").asText();
        }
        return resolved;
    }

    private boolean hasEnrollment(int userId, String courseId) {
        return findEnrollment(state, userId, courseId) != null;
    }

    private ObjectNode findEnrollment(ObjectNode source, int userId, String courseId) {
        for (JsonNode enrollment : source.path("inscriptions")) {
            if (enrollment.path("utilisateur_id").asInt() == userId
                    && courseId.equals(enrollment.path("cours_id").asText())) {
                return (ObjectNode) enrollment;
            }
        }
        return null;
    }

    private void requireEnrollment(int userId, String courseId) {
        if (!hasEnrollment(userId, courseId)) {
            throw new CatalogueApiException(403, "Inscrivez-vous au cours pour accéder à cette ressource.");
        }
    }

    private ObjectNode progressSummary(ObjectNode enrollment, ObjectNode course) {
        ObjectNode result = objectMapper.createObjectNode();
        result.set("cours", course.deepCopy());
        result.put("date_inscription", enrollment.path("date_inscription").asText());
        result.set("lecons_terminees", enrollment.path("lecons_terminees").deepCopy());
        int total = 0;
        for (JsonNode lesson : state.path("lecons")) {
            if (course.path("id").asText().equals(lesson.path("cours_id").asText())) {
                total++;
            }
        }
        int completed = enrollment.path("lecons_terminees").size();
        result.put("lecons_total", total);
        result.put("progression", total == 0 ? 0 : Math.round(completed * 10000.0 / total) / 100.0);
        return result;
    }

    private ObjectNode publicQuiz(ObjectNode quiz, boolean includeAnswers) {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("id", quiz.path("id").asText());
        result.put("cours_id", quiz.path("cours_id").asText());
        result.put("titre", quiz.path("titre").asText());
        ArrayNode questions = objectMapper.createArrayNode();
        for (JsonNode question : quiz.path("questions")) {
            ObjectNode item = objectMapper.createObjectNode();
            item.put("id", question.path("id").asText());
            item.put("texte", question.path("texte").asText());
            item.set("options", question.path("options").deepCopy());
            if (includeAnswers) {
                item.put("bonneReponse", question.path("bonne_reponse").intValue());
            }
            questions.add(item);
        }
        result.set("questions", questions);
        return result;
    }

    private ObjectNode publicAttempt(ObjectNode attempt, String quizTitle) {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("id", attempt.path("id").asText());
        result.put("cours_id", attempt.path("cours_id").asText());
        result.put("quiz_id", attempt.path("quiz_id").asText());
        result.put("quiz", quizTitle);
        result.put("score", attempt.path("score").asDouble());
        result.put("bonnes_reponses", attempt.path("bonnes_reponses").asInt());
        result.put("nombre_questions", attempt.path("nombre_questions").asInt());
        result.put("date", attempt.path("date").asText());
        return result;
    }

    private ArrayNode array(ObjectNode source, String field) {
        return (ArrayNode) source.path(field);
    }

    private ObjectNode findById(ArrayNode rows, String id) {
        for (JsonNode row : rows) {
            if (id != null && id.equals(row.path("id").asText())) {
                return (ObjectNode) row;
            }
        }
        return null;
    }

    private void removeWhere(ArrayNode rows, java.util.function.Predicate<JsonNode> predicate) {
        for (int index = rows.size() - 1; index >= 0; index--) {
            if (predicate.test(rows.get(index))) {
                rows.remove(index);
            }
        }
    }

    private void save(ObjectNode updated) throws IOException {
        persist(updated);
        state = updated;
    }

    private void persist(ObjectNode updated) throws IOException {
        byte[] json = objectMapper.writeValueAsBytes(updated);
        Path temporaryFile = Files.createTempFile(stateFile.getParent(), "plateforme-", ".tmp");
        boolean moved = false;
        try {
            Files.write(temporaryFile, json, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.move(temporaryFile, stateFile, StandardCopyOption.REPLACE_EXISTING);
            moved = true;
        } finally {
            if (!moved) {
                Files.deleteIfExists(temporaryFile);
            }
        }
    }
}
