package com.technoworld.catalogue;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@RestController
public class LearningController {
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final int PAGE_SIZE = 20;

    private final LearningStore learningStore;
    private final UtilisateurStore userStore;
    private final ObjectMapper objectMapper;

    public LearningController(
            LearningStore learningStore, UtilisateurStore userStore, ObjectMapper objectMapper) {
        this.learningStore = learningStore;
        this.userStore = userStore;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/api/categories")
    public ResponseEntity<ObjectNode> categories() {
        return success(HttpStatus.OK, learningStore.listCategories());
    }

    @GetMapping("/api/courses")
    public ResponseEntity<ObjectNode> courses(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(required = false) String categorie,
            @RequestParam(required = false) String q) {
        if (page < 1) {
            throw new CatalogueApiException(400, "Page invalide.");
        }
        ArrayNode all = learningStore.listPublishedCourses(categorie, q);
        ArrayNode items = objectMapper.createArrayNode();
        long start = (long) (page - 1) * PAGE_SIZE;
        for (long index = start; index < Math.min(start + PAGE_SIZE, all.size()); index++) {
            items.add(all.get((int) index));
        }
        ObjectNode data = objectMapper.createObjectNode();
        data.put("page", page);
        data.put("par_page", PAGE_SIZE);
        data.put("total", all.size());
        data.set("items", items);
        return success(HttpStatus.OK, data);
    }

    @GetMapping("/api/courses/{courseId}")
    public ResponseEntity<ObjectNode> courseDetails(
            @PathVariable String courseId, HttpServletRequest request) {
        UserContext user = optionalUser(request);
        return success(HttpStatus.OK,
                learningStore.courseDetails(courseId, user == null ? null : user.id(), user == null ? null : user.role()));
    }

    @PostMapping("/api/courses/{courseId}/enroll")
    public ResponseEntity<ObjectNode> enroll(@PathVariable String courseId, HttpServletRequest request)
            throws IOException {
        UserContext user = requireRole(request, "apprenant", "enseignant");
        return success(HttpStatus.CREATED, learningStore.enroll(user.id(), courseId));
    }

    @GetMapping("/api/me/courses")
    public ResponseEntity<ObjectNode> learnerCourses(HttpServletRequest request) {
        UserContext user = requireRole(request, "apprenant", "enseignant");
        return success(HttpStatus.OK, learningStore.learnerCourses(user.id()));
    }

    @PostMapping("/api/courses/{courseId}/lessons/{lessonId}/complete")
    public ResponseEntity<ObjectNode> completeLesson(
            @PathVariable String courseId,
            @PathVariable String lessonId,
            HttpServletRequest request) throws IOException {
        UserContext user = requireRole(request, "apprenant", "enseignant");
        return success(HttpStatus.OK, learningStore.markLessonComplete(user.id(), courseId, lessonId));
    }

    @GetMapping("/api/courses/{courseId}/quizzes")
    public ResponseEntity<ObjectNode> learnerQuizzes(
            @PathVariable String courseId, HttpServletRequest request) {
        UserContext user = requireRole(request, "apprenant", "enseignant");
        return success(HttpStatus.OK, learningStore.quizzesForLearner(user.id(), courseId));
    }

    @PostMapping("/api/courses/{courseId}/quizzes/{quizId}/attempts")
    public ResponseEntity<ObjectNode> submitQuiz(
            @PathVariable String courseId,
            @PathVariable String quizId,
            @RequestBody JsonNode body,
            HttpServletRequest request) throws IOException {
        UserContext user = requireRole(request, "apprenant", "enseignant");
        JsonNode answers = body == null ? null : body.get("reponses");
        if (answers == null || !answers.isObject()) {
            throw new CatalogueApiException(400, "Les réponses du quiz sont invalides.");
        }
        return success(HttpStatus.CREATED,
                learningStore.submitQuiz(user.id(), courseId, quizId, answers));
    }

    @GetMapping("/api/me/results")
    public ResponseEntity<ObjectNode> results(HttpServletRequest request) {
        UserContext user = requireRole(request, "apprenant", "enseignant");
        return success(HttpStatus.OK, learningStore.learnerResults(user.id()));
    }

    @GetMapping("/api/ranking")
    public ResponseEntity<ObjectNode> ranking() {
        ArrayNode rows = learningStore.ranking();
        for (JsonNode row : rows) {
            ObjectNode user = userStore.findPublicUser(row.path("utilisateur_id").asInt());
            ((ObjectNode) row).put("nom", user == null ? "Compte supprimé" : user.path("nom").asText());
        }
        return success(HttpStatus.OK, rows);
    }

    @GetMapping("/api/teacher/courses")
    public ResponseEntity<ObjectNode> teacherCourses(HttpServletRequest request) {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.OK, learningStore.listTeacherCourses(user.id()));
    }

    @PostMapping("/api/teacher/courses")
    public ResponseEntity<ObjectNode> createTeacherCourse(
            @RequestBody JsonNode body, HttpServletRequest request) throws IOException {
        UserContext user = requireRole(request, "enseignant");
        ObjectNode course = learningStore.createTeacherCourse(
                user.id(), user.name(), text(body, "titre", 1, 100), text(body, "description", 1, 2000),
                text(body, "categorie", 1, 100));
        return success(HttpStatus.CREATED, course);
    }

    @PutMapping("/api/teacher/courses/{courseId}")
    public ResponseEntity<ObjectNode> updateTeacherCourse(
            @PathVariable String courseId, @RequestBody JsonNode body, HttpServletRequest request)
            throws IOException {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.OK, learningStore.updateTeacherCourse(
                user.id(), courseId, text(body, "titre", 1, 100),
                text(body, "description", 1, 2000), text(body, "categorie", 1, 100)));
    }

    @DeleteMapping("/api/teacher/courses/{courseId}")
    public ResponseEntity<ObjectNode> deleteTeacherCourse(
            @PathVariable String courseId, HttpServletRequest request) throws IOException {
        requireRole(request, "enseignant");
        learningStore.deleteTeacherCourse(currentUser(request).id(), courseId);
        return success(HttpStatus.OK, message("Cours supprimé."));
    }

    @GetMapping("/api/teacher/courses/{courseId}/lessons")
    public ResponseEntity<ObjectNode> teacherLessons(
            @PathVariable String courseId, HttpServletRequest request) {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.OK, learningStore.listCourseLessons(user.id(), courseId));
    }

    @PostMapping("/api/teacher/courses/{courseId}/lessons")
    public ResponseEntity<ObjectNode> createLesson(
            @PathVariable String courseId, @RequestBody JsonNode body, HttpServletRequest request)
            throws IOException {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.CREATED, learningStore.createLesson(
                user.id(), courseId, text(body, "titre", 1, 150), text(body, "contenu", 1, 20000)));
    }

    @PutMapping("/api/teacher/courses/{courseId}/lessons/{lessonId}")
    public ResponseEntity<ObjectNode> updateLesson(
            @PathVariable String courseId, @PathVariable String lessonId,
            @RequestBody JsonNode body, HttpServletRequest request) throws IOException {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.OK, learningStore.updateLesson(
                user.id(), courseId, lessonId, text(body, "titre", 1, 150), text(body, "contenu", 1, 20000)));
    }

    @DeleteMapping("/api/teacher/courses/{courseId}/lessons/{lessonId}")
    public ResponseEntity<ObjectNode> deleteLesson(
            @PathVariable String courseId, @PathVariable String lessonId, HttpServletRequest request)
            throws IOException {
        UserContext user = requireRole(request, "enseignant");
        learningStore.deleteLesson(user.id(), courseId, lessonId);
        return success(HttpStatus.OK, message("Leçon supprimée."));
    }

    @GetMapping("/api/teacher/courses/{courseId}/quizzes")
    public ResponseEntity<ObjectNode> teacherQuizzes(
            @PathVariable String courseId, HttpServletRequest request) {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.OK, learningStore.quizzesForTeacher(user.id(), courseId));
    }

    @PostMapping("/api/teacher/courses/{courseId}/quizzes")
    public ResponseEntity<ObjectNode> createQuiz(
            @PathVariable String courseId, @RequestBody JsonNode body, HttpServletRequest request)
            throws IOException {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.CREATED, learningStore.createQuiz(
                user.id(), courseId, text(body, "titre", 1, 150), questions(body)));
    }

    @PutMapping("/api/teacher/courses/{courseId}/quizzes/{quizId}")
    public ResponseEntity<ObjectNode> updateQuiz(
            @PathVariable String courseId, @PathVariable String quizId,
            @RequestBody JsonNode body, HttpServletRequest request) throws IOException {
        UserContext user = requireRole(request, "enseignant");
        return success(HttpStatus.OK, learningStore.updateQuiz(
                user.id(), courseId, quizId, text(body, "titre", 1, 150), questions(body)));
    }

    @DeleteMapping("/api/teacher/courses/{courseId}/quizzes/{quizId}")
    public ResponseEntity<ObjectNode> deleteQuiz(
            @PathVariable String courseId, @PathVariable String quizId, HttpServletRequest request)
            throws IOException {
        UserContext user = requireRole(request, "enseignant");
        learningStore.deleteQuiz(user.id(), courseId, quizId);
        return success(HttpStatus.OK, message("Quiz supprimé."));
    }

    @GetMapping("/api/admin/users")
    public ResponseEntity<ObjectNode> adminUsers(HttpServletRequest request) {
        requireRole(request, "administrateur");
        ArrayNode users = objectMapper.createArrayNode();
        userStore.listPublicUsers().forEach(users::add);
        return success(HttpStatus.OK, users);
    }

    @PostMapping("/api/admin/users")
    public ResponseEntity<ObjectNode> createUser(
            @RequestBody JsonNode body, HttpServletRequest request) throws IOException {
        requireRole(request, "administrateur");
        String name = text(body, "nom", 1, 100);
        String email = email(body, "email");
        String role = text(body, "role", 1, 30);
        char[] password = password(body);
        try {
            validatePassword(password);
            return success(HttpStatus.CREATED,
                    userStore.createManagedUser(name, email, password, role));
        } finally {
            java.util.Arrays.fill(password, '\0');
        }
    }

    @PutMapping("/api/admin/users/{userId}")
    public ResponseEntity<ObjectNode> updateUser(
            @PathVariable int userId, @RequestBody JsonNode body, HttpServletRequest request)
            throws IOException {
        requireRole(request, "administrateur");
        String name = optionalText(body, "nom", 100);
        if (name != null && name.isBlank()) {
            throw new CatalogueApiException(400, "Le nom du compte ne peut pas être vide.");
        }
        String email = body.has("email") ? email(body, "email") : null;
        String role = optionalText(body, "role", 30);
        char[] password = body.has("motDePasse") ? password(body) : null;
        try {
            if (password != null) {
                validatePassword(password);
            }
            return success(HttpStatus.OK, userStore.updateManagedUser(userId, name, email, role, password));
        } finally {
            if (password != null) {
                java.util.Arrays.fill(password, '\0');
            }
        }
    }

    @DeleteMapping("/api/admin/users/{userId}")
    public ResponseEntity<ObjectNode> deleteUser(
            @PathVariable int userId, HttpServletRequest request) throws IOException {
        UserContext current = requireRole(request, "administrateur");
        if (userId == current.id()) {
            throw new CatalogueApiException(409, "Vous ne pouvez pas supprimer votre propre compte.");
        }
        userStore.deleteManagedUser(userId);
        return success(HttpStatus.OK, message("Utilisateur supprimé."));
    }

    @GetMapping("/api/admin/courses/pending")
    public ResponseEntity<ObjectNode> pendingCourses(HttpServletRequest request) {
        requireRole(request, "administrateur");
        return success(HttpStatus.OK, learningStore.pendingCourses());
    }

    @PostMapping("/api/admin/courses/{courseId}/decision")
    public ResponseEntity<ObjectNode> decideCourse(
            @PathVariable String courseId, @RequestBody JsonNode body, HttpServletRequest request)
            throws IOException {
        requireRole(request, "administrateur");
        JsonNode approved = body == null ? null : body.get("approuve");
        if (approved == null || !approved.isBoolean()) {
            throw new CatalogueApiException(400, "La décision d’approbation est obligatoire.");
        }
        String reason = optionalText(body, "motif", 500);
        if (!approved.booleanValue() && (reason == null || reason.isBlank())) {
            throw new CatalogueApiException(400, "Le motif du refus est obligatoire.");
        }
        return success(HttpStatus.OK,
                learningStore.decideCourse(courseId, approved.booleanValue(), reason == null ? "" : reason));
    }

    @PostMapping("/api/admin/categories")
    public ResponseEntity<ObjectNode> createCategory(
            @RequestBody JsonNode body, HttpServletRequest request) throws IOException {
        requireRole(request, "administrateur");
        return success(HttpStatus.CREATED, learningStore.createCategory(text(body, "nom", 1, 100)));
    }

    @PutMapping("/api/admin/categories/{categoryId}")
    public ResponseEntity<ObjectNode> updateCategory(
            @PathVariable int categoryId, @RequestBody JsonNode body, HttpServletRequest request)
            throws IOException {
        requireRole(request, "administrateur");
        return success(HttpStatus.OK,
                learningStore.updateCategory(categoryId, text(body, "nom", 1, 100)));
    }

    @DeleteMapping("/api/admin/categories/{categoryId}")
    public ResponseEntity<ObjectNode> deleteCategory(
            @PathVariable int categoryId, HttpServletRequest request) throws IOException {
        requireRole(request, "administrateur");
        learningStore.deleteCategory(categoryId);
        return success(HttpStatus.OK, message("Catégorie supprimée."));
    }

    @ExceptionHandler(CatalogueApiException.class)
    public ResponseEntity<ObjectNode> handleApiError(CatalogueApiException exception) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", false);
        body.put("message", exception.getMessage());
        return ResponseEntity.status(exception.getStatus()).body(body);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ObjectNode> handleInvalidJson() {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", false);
        body.put("message", "Corps JSON illisible.");
        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<ObjectNode> handlePersistenceError() {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", false);
        body.put("message", "Impossible d’enregistrer les modifications.");
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }

    private UserContext currentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || !(session.getAttribute("userId") instanceof Integer userId)) {
            throw new CatalogueApiException(401, "Connexion requise.");
        }
        ObjectNode user = userStore.findPublicUser(userId);
        if (user == null) {
            session.invalidate();
            throw new CatalogueApiException(401, "Connexion requise.");
        }
        return new UserContext(userId, user.path("role").asText(), user.path("nom").asText());
    }

    private UserContext optionalUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || !(session.getAttribute("userId") instanceof Integer userId)) {
            return null;
        }
        ObjectNode user = userStore.findPublicUser(userId);
        return user == null ? null : new UserContext(userId, user.path("role").asText(), user.path("nom").asText());
    }

    private UserContext requireRole(HttpServletRequest request, String... allowedRoles) {
        UserContext user = currentUser(request);
        for (String role : allowedRoles) {
            if (role.equals(user.role())) {
                return user;
            }
        }
        throw new CatalogueApiException(403, "Votre rôle ne permet pas cette opération.");
    }

    private String text(JsonNode body, String field, int minLength, int maxLength) {
        JsonNode value = body == null ? null : body.get(field);
        if (value == null || !value.isTextual()) {
            throw new CatalogueApiException(400, "Champ invalide : " + field + ".");
        }
        String text = value.textValue().trim();
        int length = text.codePointCount(0, text.length());
        if (length < minLength || length > maxLength) {
            throw new CatalogueApiException(400, "Champ invalide : " + field + ".");
        }
        return text;
    }

    private String optionalText(JsonNode body, String field, int maxLength) {
        JsonNode value = body == null ? null : body.get(field);
        if (value == null || value.isNull()) {
            return null;
        }
        if (!value.isTextual()) {
            throw new CatalogueApiException(400, "Champ invalide : " + field + ".");
        }
        String text = value.textValue().trim();
        if (text.codePointCount(0, text.length()) > maxLength) {
            throw new CatalogueApiException(400, "Champ invalide : " + field + ".");
        }
        return text;
    }

    private String email(JsonNode body, String field) {
        String value = text(body, field, 3, 254);
        if (!EMAIL_PATTERN.matcher(value).matches()) {
            throw new CatalogueApiException(400, "Adresse courriel invalide.");
        }
        return value;
    }

    private char[] password(JsonNode body) {
        String value = text(body, "motDePasse", 8, 128);
        return value.toCharArray();
    }

    private void validatePassword(char[] password) {
        if (password.length < 8 || password.length > 128) {
            throw new CatalogueApiException(400, "Le mot de passe doit contenir entre 8 et 128 caractères.");
        }
    }

    private ArrayNode questions(JsonNode body) {
        JsonNode questions = body == null ? null : body.get("questions");
        if (questions == null || !questions.isArray() || questions.isEmpty() || questions.size() > 50) {
            throw new CatalogueApiException(400, "Un quiz doit contenir entre 1 et 50 questions.");
        }
        ArrayNode validated = objectMapper.createArrayNode();
        for (JsonNode question : questions) {
            String text = text(question, "texte", 1, 1000);
            JsonNode options = question.get("options");
            JsonNode correct = question.get("bonneReponse");
            if (options == null || !options.isArray() || options.size() < 2 || options.size() > 10
                    || correct == null || !correct.canConvertToInt()
                    || correct.intValue() < 0 || correct.intValue() >= options.size()) {
                throw new CatalogueApiException(400, "Options ou bonne réponse invalides.");
            }
            List<String> optionValues = new ArrayList<>();
            for (JsonNode option : options) {
                if (!option.isTextual() || option.textValue().trim().isEmpty()
                        || option.textValue().codePointCount(0, option.textValue().length()) > 500) {
                    throw new CatalogueApiException(400, "Options ou bonne réponse invalides.");
                }
                optionValues.add(option.textValue().trim());
            }
            ObjectNode item = objectMapper.createObjectNode();
            item.put("texte", text);
            item.set("options", objectMapper.valueToTree(optionValues));
            item.put("bonneReponse", correct.intValue());
            validated.add(item);
        }
        return validated;
    }

    private ObjectNode message(String text) {
        ObjectNode result = objectMapper.createObjectNode();
        result.put("message", text);
        return result;
    }

    private ResponseEntity<ObjectNode> success(HttpStatus status, JsonNode data) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("success", true);
        body.set("data", data);
        return ResponseEntity.status(status).body(body);
    }

    private record UserContext(int id, String role, String name) {
    }
}
