package com.technoworld.catalogue;

public class CatalogueApiException extends RuntimeException {
    private final int status;

    public CatalogueApiException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
