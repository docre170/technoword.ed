package com.technoworld.catalogue;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PageController {
    @GetMapping(value = {"/", "/connexion", "/inscription"}, produces = MediaType.TEXT_HTML_VALUE)
    public Resource authenticationPage() {
        return new ClassPathResource("static/app.html");
    }
}
