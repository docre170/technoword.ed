import http from 'k6/http';
import { check } from 'k6';

const BASE = __ENV.BASE || 'http://127.0.0.1:8080';
const VUS = Number(__ENV.VUS || 10);
const DUREE = __ENV.DUREE || '10s';
const MOTS = ['algo', 'bio', 'réseaux', 'génétique', 'cours 1', 'données'];

export const options = {
  vus: VUS,
  duration: DUREE,
  summaryTrendStats: ['avg', 'med', 'p(95)', 'p(99)', 'max'],
};

export default function () {
  const r = Math.random();
  let res;
  if (r < 0.5) {
    res = http.get(`${BASE}/cours?page=${1 + Math.floor(Math.random() * 250)}`, { tags: { route: 'liste' } });
  } else if (r < 0.8) {
    const q = encodeURIComponent(MOTS[Math.floor(Math.random() * MOTS.length)]);
    res = http.get(`${BASE}/cours/recherche?q=${q}`, { tags: { route: 'recherche' } });
  } else {
    res = http.get(`${BASE}/cours/${1 + Math.floor(Math.random() * 5000)}/moyenne`, { tags: { route: 'moyenne' } });
  }
  check(res, { 'statut 200': (x) => x.status === 200 });
}