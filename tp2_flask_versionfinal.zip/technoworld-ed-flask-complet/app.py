import os, secrets
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, abort, g
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func, and_
from config.settings import Settings
from models.entities import db, User, Category, Course, Lesson, Quiz, Question, Answer, Enrollment, Result
from data.utilisateur_store import sync_users_json

app = Flask(__name__)
app.config.from_object(Settings)
db.init_app(app)

@app.context_processor
def globals_for_templates():
    return {"current_user": current_user(), "csrf_token": csrf_token()}

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def csrf_token():
    if "csrf" not in session: session["csrf"] = secrets.token_urlsafe(32)
    return session["csrf"]

def valid_csrf():
    return request.form.get("csrf") == session.get("csrf")

def login_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            user = current_user()
            if not user: return redirect(url_for("login", next=request.path)) if not request.path.startswith("/api/") else api_error("Authentification requise", 401)
            if roles and user.role not in roles: return api_error("Accès refusé", 403) if request.path.startswith("/api/") else abort(403)
            g.user = user
            return fn(*args, **kwargs)
        return wrapped
    return decorator

def api_ok(data=None, message=""):
    return jsonify(success=True, data=data, message=message)

def api_error(message, status=400):
    return jsonify(success=False, data=None, message=message), status

def clean(value, limit):
    value = (value or "").strip()
    return value if 1 <= len(value) <= limit else None

def public_course_query():
    q = Course.query.filter_by(statut="publie")
    category = request.args.get("categorie", type=int)
    return q.filter_by(categorie_id=category) if category else q

@app.get("/")
def home(): return render_template("index.html", courses=public_course_query().all(), categories=Category.query.order_by(Category.nom).all())

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        if not valid_csrf(): abort(403)
        nom, email, password = clean(request.form.get("nom"), 120), clean(request.form.get("email"), 254), request.form.get("password", "")
        if not nom or len(nom) < 2 or not email or "@" not in email or len(password) < 8: return render_template("register.html", error="Vérifiez votre nom, votre adresse email et votre mot de passe (8 caractères minimum).")
        sync_users_json()
        if User.query.filter_by(email=email.lower()).first(): return render_template("register.html", error="Email déjà utilisé.")
        db.session.add(User(nom=nom, email=email.lower(), mot_de_passe=generate_password_hash(password)))
        db.session.commit(); sync_users_json(); return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not valid_csrf(): abort(403)
        sync_users_json()
        user = User.query.filter_by(email=request.form.get("email", "").lower().strip()).first()
        if not user or not check_password_hash(user.mot_de_passe, request.form.get("password", "")): return render_template("login.html", error="Identifiants invalides.")
        session.clear(); session["user_id"] = user.id; session["csrf"] = secrets.token_urlsafe(32); return redirect(request.args.get("next") or url_for("home"))
    return render_template("login.html")

@app.post("/logout")
@login_required("apprenant", "enseignant", "admin")
def logout():
    if not valid_csrf(): abort(403)
    session.clear(); return redirect(url_for("home"))

@app.get("/cours/<int:course_id>")
def course_detail(course_id):
    course = db.session.get(Course, course_id)
    if not course or course.statut != "publie": abort(404)
    return render_template("course.html", course=course, enrollment=Enrollment.query.filter_by(utilisateur_id=session.get("user_id"), cours_id=course.id).first())

@app.post("/cours/<int:course_id>/inscription")
@login_required("apprenant", "enseignant", "admin")
def enroll(course_id):
    if not valid_csrf(): abort(403)
    if not db.session.get(Course, course_id): abort(404)
    if not Enrollment.query.filter_by(utilisateur_id=g.user.id, cours_id=course_id).first(): db.session.add(Enrollment(utilisateur_id=g.user.id, cours_id=course_id)); db.session.commit()
    return redirect(url_for("course_detail", course_id=course_id))

@app.post("/lecons/<int:lesson_id>/lue")
@login_required("apprenant", "enseignant", "admin")
def mark_lesson(lesson_id):
    if not valid_csrf(): abort(403)
    lesson = db.session.get(Lesson, lesson_id); course = db.session.get(Course, lesson.cours_id) if lesson else None
    enrollment = Enrollment.query.filter_by(utilisateur_id=g.user.id, cours_id=course.id).first() if course else None
    if enrollment:
        total, done = Lesson.query.filter_by(cours_id=course.id).count(), max(0, enrollment.progression * Lesson.query.filter_by(cours_id=course.id).count() // 100)
        enrollment.progression = min(100, int((done + 1) * 100 / total)) if total else 100; db.session.commit()
    return redirect(url_for("course_detail", course_id=course.id))

@app.route("/enseignant/cours", methods=["GET", "POST"])
@login_required("enseignant", "admin")
def teacher_courses():
    if request.method == "POST":
        if not valid_csrf(): abort(403)
        titre, description, cat = clean(request.form.get("titre"), 200), clean(request.form.get("description"), 5000), request.form.get("categorie_id", type=int)
        if not titre or not description or not cat: abort(400)
        db.session.add(Course(titre=titre, description=description, auteur_id=g.user.id, categorie_id=cat)); db.session.commit(); return redirect(url_for("teacher_courses"))
    return render_template("teacher_courses.html", courses=Course.query.filter_by(auteur_id=g.user.id).all(), categories=Category.query.all())

@app.post("/enseignant/cours/<int:course_id>/modifier")
@login_required("enseignant", "admin")
def update_course(course_id):
    if not valid_csrf(): abort(403)
    course = Course.query.filter_by(id=course_id, auteur_id=g.user.id).first_or_404(); course.titre=clean(request.form.get("titre"),200); course.description=clean(request.form.get("description"),5000); course.categorie_id=request.form.get("categorie_id",type=int); course.statut="en_attente"; db.session.commit(); return redirect(url_for("teacher_courses"))

@app.post("/enseignant/cours/<int:course_id>/supprimer")
@login_required("enseignant", "admin")
def delete_course(course_id):
    if not valid_csrf(): abort(403)
    course = Course.query.filter_by(id=course_id, auteur_id=g.user.id).first_or_404(); db.session.delete(course); db.session.commit(); return redirect(url_for("teacher_courses"))

@app.post("/enseignant/cours/<int:course_id>/lecons")
@login_required("enseignant", "admin")
def create_lesson(course_id):
    if not valid_csrf(): abort(403)
    Course.query.filter_by(id=course_id, auteur_id=g.user.id).first_or_404(); db.session.add(Lesson(titre=clean(request.form.get("titre"),200), contenu=clean(request.form.get("contenu"),10000), ordre=request.form.get("ordre",1,type=int), cours_id=course_id)); db.session.commit(); return redirect(url_for("teacher_courses"))

@app.post("/enseignant/cours/<int:course_id>/quiz")
@login_required("enseignant", "admin")
def create_quiz(course_id):
    if not valid_csrf(): abort(403)
    Course.query.filter_by(id=course_id, auteur_id=g.user.id).first_or_404(); quiz=Quiz(titre=clean(request.form.get("titre"),200), cours_id=course_id); db.session.add(quiz); db.session.commit(); return redirect(url_for("teacher_courses"))

@app.get("/quiz/<int:quiz_id>")
@login_required("apprenant", "enseignant", "admin")
def quiz_page(quiz_id): return render_template("quiz.html", quiz=db.session.get(Quiz, quiz_id))

@app.post("/quiz/<int:quiz_id>/submit")
@login_required("apprenant", "enseignant", "admin")
def submit_quiz(quiz_id):
    if not valid_csrf(): abort(403)
    quiz=db.session.get(Quiz, quiz_id); score=0
    for question in quiz.questions:
        chosen=request.form.get(f"question_{question.id}", type=int)
        if any(answer.id == chosen and answer.est_correcte for answer in question.reponses): score += 1
    db.session.add(Result(utilisateur_id=g.user.id, quiz_id=quiz.id, score=score, total=len(quiz.questions))); db.session.commit(); return render_template("quiz_result.html", score=score, total=len(quiz.questions))

@app.get("/mes-resultats")
@login_required("apprenant", "enseignant", "admin")
def results():
    rows=Result.query.filter_by(utilisateur_id=g.user.id).order_by(Result.date_passage.desc()).all()
    ranking=db.session.query(User.nom, func.sum(Result.score).label("total")).join(Result, Result.utilisateur_id==User.id).group_by(User.id).order_by(func.sum(Result.score).desc()).all()
    return render_template("results.html", results=rows, ranking=ranking)

@app.get("/admin/cours")
@login_required("admin")
def admin_courses(): return render_template("admin_courses.html", courses=Course.query.order_by(Course.created_at.desc()).all())
@app.post("/admin/cours/<int:course_id>")
@login_required("admin")
def admin_course_action(course_id):
    if not valid_csrf(): abort(403)
    course=db.session.get(Course,course_id); course.statut=request.form.get("action") if request.form.get("action") in ("publie","refuse") else course.statut; db.session.commit(); return redirect(url_for("admin_courses"))
@app.get("/admin/utilisateurs")
@login_required("admin")
def admin_users():
    sync_users_json()
    return render_template("admin_users.html", users=User.query.all())
@app.post("/admin/utilisateurs/<int:user_id>")
@login_required("admin")
def admin_user_action(user_id):
    if not valid_csrf(): abort(403)
    u=db.session.get(User,user_id); u.role=request.form.get("role") if request.form.get("role") in ("apprenant","enseignant","admin") else u.role; db.session.commit(); sync_users_json(); return redirect(url_for("admin_users"))
@app.route("/admin/categories", methods=["GET","POST"])
@login_required("admin")
def admin_categories():
    if request.method=="POST":
        if not valid_csrf(): abort(403)
        name=clean(request.form.get("nom"),120)
        if name: db.session.add(Category(nom=name)); db.session.commit()
    return render_template("admin_categories.html", categories=Category.query.all())

# API JSON : les quiz masquent est_correcte jusqu’à la soumission.
@app.post("/api/register")
def api_register():
    data=request.get_json(silent=True) or {}; nom,email,password=clean(data.get("nom"),120),clean(data.get("email"),254),data.get("password","")
    if not nom or len(nom)<2 or not email or "@" not in email or len(password)<8: return api_error("Données invalides")
    sync_users_json()
    if User.query.filter_by(email=email.lower()).first(): return api_error("Email déjà utilisé",409)
    u=User(nom=nom,email=email.lower(),mot_de_passe=generate_password_hash(password),token=secrets.token_urlsafe(32)); db.session.add(u); db.session.commit(); sync_users_json(); return api_ok({"id":u.id,"token":u.token},"Compte créé")
@app.post("/api/login")
def api_login():
    sync_users_json()
    data=request.get_json(silent=True) or {}; u=User.query.filter_by(email=data.get("email","").lower().strip()).first()
    if not u or not check_password_hash(u.mot_de_passe,data.get("password","")): return api_error("Identifiants invalides",401)
    session["user_id"]=u.id; u.token=u.token or secrets.token_urlsafe(32); db.session.commit(); sync_users_json(); return api_ok({"id":u.id,"role":u.role,"token":u.token},"Connexion réussie")
def api_auth(fn):
    @wraps(fn)
    def wrapped(*args,**kwargs):
        auth=request.headers.get("Authorization","").replace("Bearer ","").strip(); u=User.query.filter_by(token=auth).first() if auth else current_user()
        if not u: return api_error("Authentification requise",401)
        g.user=u; return fn(*args,**kwargs)
    return wrapped
@app.get("/api/cours")
def api_courses(): return api_ok([{"id":c.id,"titre":c.titre,"description":c.description,"categorie":c.categorie.nom} for c in public_course_query().all()],"Cours publiés")
@app.get("/api/cours/<int:course_id>")
def api_course(course_id):
    c=Course.query.filter_by(id=course_id,statut="publie").first_or_404(); return api_ok({"id":c.id,"titre":c.titre,"description":c.description,"lecons":[{"id":l.id,"titre":l.titre,"contenu":l.contenu,"ordre":l.ordre} for l in c.lecons]},"Cours trouvé")
@app.get("/api/quiz/<int:quiz_id>")
def api_quiz(quiz_id):
    q=db.session.get(Quiz,quiz_id); return api_ok({"id":q.id,"titre":q.titre,"questions":[{"id":x.id,"enonce":x.enonce,"reponses":[{"id":a.id,"texte":a.texte} for a in x.reponses]} for x in q.questions]},"Quiz trouvé")
@app.post("/api/quiz/<int:quiz_id>/submit")
@api_auth
def api_submit(quiz_id):
    q=db.session.get(Quiz,quiz_id); data=request.get_json(silent=True) or {}; answers=data.get("answers",{}); score=sum(1 for x in q.questions for a in x.reponses if a.est_correcte and int(answers.get(str(x.id),0))==a.id); r=Result(utilisateur_id=g.user.id,quiz_id=q.id,score=score,total=len(q.questions)); db.session.add(r); db.session.commit(); return api_ok({"score":score,"total":r.total},"Résultat enregistré")
@app.get("/api/resultats")
@api_auth
def api_results(): return api_ok([{"score":r.score,"total":r.total,"date":r.date_passage.isoformat()} for r in Result.query.filter_by(utilisateur_id=g.user.id).all()],"Résultats")

@app.cli.command("init-db")
def init_db(): db.create_all(); print("Base initialisée.")

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        sync_users_json()
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)), debug=os.getenv("FLASK_DEBUG","false").lower()=="true")
