# TechnoWorld Ed — Flask

Plateforme d’e-learning en Python 3, Flask, SQLAlchemy, PyMySQL, MySQL 8, Bootstrap 5 et Jinja2.

## Installation

Créer un environnement virtuel puis installer les dépendances :

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Créer la base et charger les données :

```bash
mysql -u root -p < sql/schema_and_seed.sql
python app.py
```

L’application écoute sur `http://localhost:5000`.

Les comptes créés par les formulaires web ou l’API sont également synchronisés
dans `data/utilisateurs.json`. Les mots de passe y sont enregistrés sous forme
hachée, jamais en clair. La base SQL reste utilisée pour les relations entre
utilisateurs, cours et résultats.

Comptes de test : `admin@technoworld.test`, `enseignant@technoworld.test`, `apprenant1@technoworld.test`, `apprenant2@technoworld.test`. Mot de passe : `password`.

## Tests manuels

L’apprenant doit pouvoir s’inscrire, se connecter, filtrer les cours, s’inscrire à un cours, marquer des leçons comme lues, passer un quiz et consulter ses résultats. L’enseignant doit pouvoir créer et modifier uniquement ses cours, ajouter des leçons et des quiz, avec un statut initial `en_attente`. L’administrateur doit pouvoir publier/refuser des cours, modifier les rôles et ajouter des catégories. L’API doit répondre avec `{success,data,message}`, masquer `est_correcte` lors de la consultation d’un quiz et exiger une session ou un jeton Bearer pour les opérations protégées.

## Déploiement

Définir `SECRET_KEY`, les variables MySQL et `COOKIE_SECURE=true` derrière HTTPS. Utiliser Gunicorn ou un serveur WSGI équivalent en production : `gunicorn -w 4 app:app`.
