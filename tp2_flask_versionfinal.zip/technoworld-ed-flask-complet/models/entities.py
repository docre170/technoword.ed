from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

# Instance ORM partagée par l’application.
db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "utilisateur"
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(254), unique=True, nullable=False)
    mot_de_passe = db.Column(db.String(255), nullable=False)
    role = db.Column(db.Enum("apprenant", "enseignant", "admin"), nullable=False, default="apprenant")
    token = db.Column(db.String(128), unique=True, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Category(db.Model):
    __tablename__ = "categorie"
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(120), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Course(db.Model):
    __tablename__ = "cours"
    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    statut = db.Column(db.Enum("brouillon", "en_attente", "publie", "refuse"), default="en_attente", nullable=False)
    prix = db.Column(db.Numeric(10, 2), default=0, nullable=False)
    acces = db.Column(db.Enum("gratuit", "premium"), default="gratuit", nullable=False)
    auteur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=False)
    categorie_id = db.Column(db.Integer, db.ForeignKey("categorie.id"), nullable=False)
    auteur = db.relationship("User")
    categorie = db.relationship("Category")
    lecons = db.relationship("Lesson", cascade="all, delete-orphan", order_by="Lesson.ordre")
    quizzes = db.relationship("Quiz", cascade="all, delete-orphan")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Lesson(db.Model):
    __tablename__ = "lecon"
    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(200), nullable=False)
    contenu = db.Column(db.Text, nullable=False)
    ordre = db.Column(db.Integer, nullable=False, default=1)
    cours_id = db.Column(db.Integer, db.ForeignKey("cours.id", ondelete="CASCADE"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Quiz(db.Model):
    __tablename__ = "quiz"
    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(200), nullable=False)
    cours_id = db.Column(db.Integer, db.ForeignKey("cours.id", ondelete="CASCADE"), nullable=False)
    questions = db.relationship("Question", cascade="all, delete-orphan")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Question(db.Model):
    __tablename__ = "question"
    id = db.Column(db.Integer, primary_key=True)
    enonce = db.Column(db.Text, nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey("quiz.id", ondelete="CASCADE"), nullable=False)
    reponses = db.relationship("Answer", cascade="all, delete-orphan")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Answer(db.Model):
    __tablename__ = "reponse"
    id = db.Column(db.Integer, primary_key=True)
    texte = db.Column(db.String(500), nullable=False)
    est_correcte = db.Column(db.Boolean, default=False, nullable=False)
    question_id = db.Column(db.Integer, db.ForeignKey("question.id", ondelete="CASCADE"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Enrollment(db.Model):
    __tablename__ = "inscription"
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", ondelete="CASCADE"), primary_key=True)
    cours_id = db.Column(db.Integer, db.ForeignKey("cours.id", ondelete="CASCADE"), primary_key=True)
    progression = db.Column(db.Integer, default=0, nullable=False)
    date_inscription = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

class Result(db.Model):
    __tablename__ = "resultat"
    id = db.Column(db.Integer, primary_key=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", ondelete="CASCADE"), nullable=False)
    quiz_id = db.Column(db.Integer, db.ForeignKey("quiz.id", ondelete="CASCADE"), nullable=False)
    score = db.Column(db.Integer, nullable=False)
    total = db.Column(db.Integer, nullable=False)
    date_passage = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
