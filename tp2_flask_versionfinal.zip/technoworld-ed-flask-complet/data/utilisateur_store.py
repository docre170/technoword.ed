import json
import os

from models.entities import User


USERS_FILE = os.path.join(os.path.dirname(__file__), "utilisateurs.json")


def sync_users_json():
    users = [
        {
            "id": user.id,
            "nom": user.nom,
            "email": user.email,
            "mot_de_passe": user.mot_de_passe,
            "role": user.role,
            "token": user.token,
            "created_at": user.created_at.isoformat(),
            "updated_at": user.updated_at.isoformat(),
        }
        for user in User.query.order_by(User.id).all()
    ]

    temporary_file = f"{USERS_FILE}.tmp"
    with open(temporary_file, "w", encoding="utf-8") as file:
        json.dump(users, file, ensure_ascii=False, indent=2)
        file.write("\n")
    os.replace(temporary_file, USERS_FILE)
    return users
