# TechnoWorld Ed

Plateforme d’e-learning en informatique et biomédecine, développée en Go, Gin, GORM, MySQL 8 et `html/template`.

## Étape 1

Cette première étape fournit :

- l’arborescence de base du projet ;
- le module Go et les dépendances prévues ;
- le modèle `.env.example` ;
- le script SQL de structure et de données de test dans `sql/schema_and_seed.sql`.

Les répertoires applicatifs seront remplis dans les étapes suivantes, dans l’ordre défini par le cahier des charges.

## Identifiants de test

Le script SQL utilise le mot de passe `password` pour les comptes de test. Il devra être remplacé dans un environnement réel.
