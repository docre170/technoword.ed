-- TechnoWorld Ed — structure MySQL 8 et données de test
-- Encodage : utf8mb4 | Moteur : InnoDB

CREATE DATABASE IF NOT EXISTS technoworld_ed
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE technoworld_ed;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS resultat;
DROP TABLE IF EXISTS inscription;
DROP TABLE IF EXISTS reponse;
DROP TABLE IF EXISTS question;
DROP TABLE IF EXISTS quiz;
DROP TABLE IF EXISTS lecon;
DROP TABLE IF EXISTS cours;
DROP TABLE IF EXISTS categorie;
DROP TABLE IF EXISTS utilisateur;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE utilisateur (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nom VARCHAR(120) NOT NULL,
  email VARCHAR(254) NOT NULL,
  mot_de_passe VARCHAR(255) NOT NULL,
  role ENUM('apprenant', 'enseignant', 'admin') NOT NULL DEFAULT 'apprenant',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_utilisateur_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categorie (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  nom VARCHAR(120) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categorie_nom (nom)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cours (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  titre VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  statut ENUM('brouillon', 'en_attente', 'publie', 'refuse') NOT NULL DEFAULT 'en_attente',
  prix DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  acces ENUM('gratuit', 'premium') NOT NULL DEFAULT 'gratuit',
  auteur_id BIGINT UNSIGNED NOT NULL,
  categorie_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_cours_statut (statut),
  KEY idx_cours_categorie (categorie_id),
  CONSTRAINT fk_cours_auteur FOREIGN KEY (auteur_id) REFERENCES utilisateur(id),
  CONSTRAINT fk_cours_categorie FOREIGN KEY (categorie_id) REFERENCES categorie(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lecon (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  titre VARCHAR(200) NOT NULL,
  contenu LONGTEXT NOT NULL,
  ordre INT NOT NULL DEFAULT 1,
  cours_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_lecon_cours_ordre (cours_id, ordre),
  CONSTRAINT fk_lecon_cours FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE quiz (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  titre VARCHAR(200) NOT NULL,
  cours_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_quiz_cours (cours_id),
  CONSTRAINT fk_quiz_cours FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE question (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  enonce TEXT NOT NULL,
  quiz_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_question_quiz (quiz_id),
  CONSTRAINT fk_question_quiz FOREIGN KEY (quiz_id) REFERENCES quiz(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reponse (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  texte VARCHAR(500) NOT NULL,
  est_correcte BOOLEAN NOT NULL DEFAULT FALSE,
  question_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_reponse_question (question_id),
  CONSTRAINT fk_reponse_question FOREIGN KEY (question_id) REFERENCES question(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE inscription (
  utilisateur_id BIGINT UNSIGNED NOT NULL,
  cours_id BIGINT UNSIGNED NOT NULL,
  progression INT NOT NULL DEFAULT 0,
  date_inscription TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (utilisateur_id, cours_id),
  CONSTRAINT chk_inscription_progression CHECK (progression BETWEEN 0 AND 100),
  CONSTRAINT fk_inscription_utilisateur FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
  CONSTRAINT fk_inscription_cours FOREIGN KEY (cours_id) REFERENCES cours(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE resultat (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  utilisateur_id BIGINT UNSIGNED NOT NULL,
  quiz_id BIGINT UNSIGNED NOT NULL,
  score INT NOT NULL,
  total INT NOT NULL,
  date_passage TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_resultat_utilisateur (utilisateur_id),
  KEY idx_resultat_quiz (quiz_id),
  CONSTRAINT chk_resultat_score CHECK (score >= 0 AND score <= total),
  CONSTRAINT chk_resultat_total CHECK (total > 0),
  CONSTRAINT fk_resultat_utilisateur FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
  CONSTRAINT fk_resultat_quiz FOREIGN KEY (quiz_id) REFERENCES quiz(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Le hash ci-dessous correspond au mot de passe de test : password
INSERT INTO utilisateur (id, nom, email, mot_de_passe, role) VALUES
  (1, 'Administrateur de test', 'admin@technoworld.test', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'admin'),
  (2, 'Enseignant de test', 'enseignant@technoworld.test', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'enseignant'),
  (3, 'Apprenant Un', 'apprenant1@technoworld.test', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'apprenant'),
  (4, 'Apprenant Deux', 'apprenant2@technoworld.test', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'apprenant');

INSERT INTO categorie (id, nom) VALUES
  (1, 'Informatique'),
  (2, 'Biomédecine'),
  (3, 'Bio-informatique');

INSERT INTO cours (id, titre, description, statut, prix, acces, auteur_id, categorie_id) VALUES
  (1, 'Fondamentaux de Go', 'Découvrir la syntaxe, les types et les bonnes pratiques du langage Go.', 'publie', 0.00, 'gratuit', 2, 1),
  (2, 'Introduction à la bio-informatique', 'Comprendre les notions de base des séquences biologiques et de leur analyse.', 'publie', 0.00, 'gratuit', 2, 3);

INSERT INTO lecon (id, titre, contenu, ordre, cours_id) VALUES
  (1, 'Variables et fonctions en Go', 'Les variables, les fonctions et les valeurs de retour en Go.', 1, 1),
  (2, 'Structures de contrôle', 'Les conditions, les boucles et les instructions switch.', 2, 1),
  (3, 'Séquences biologiques', 'ADN, ARN et représentation informatique des séquences.', 1, 2),
  (4, 'Alignement de séquences', 'Principes généraux de comparaison de séquences.', 2, 2);

INSERT INTO quiz (id, titre, cours_id) VALUES
  (1, 'Quiz — Fondamentaux de Go', 1),
  (2, 'Quiz — Bio-informatique', 2);

INSERT INTO question (id, enonce, quiz_id) VALUES
  (1, 'Quel mot-clé déclare une fonction en Go ?', 1),
  (2, 'Quel est le rôle principal de la fonction main ?', 1),
  (3, 'Quelle molécule contient généralement les bases A, T, C et G ?', 2),
  (4, 'À quoi sert un alignement de séquences ?', 2);

INSERT INTO reponse (id, texte, est_correcte, question_id) VALUES
  (1, 'func', TRUE, 1),
  (2, 'function', FALSE, 1),
  (3, 'fn', FALSE, 1),
  (4, 'Démarrer l’exécution du programme', TRUE, 2),
  (5, 'Créer une base de données', FALSE, 2),
  (6, 'L’ADN', TRUE, 3),
  (7, 'Les protéines uniquement', FALSE, 3),
  (8, 'Comparer des séquences pour repérer des similarités', TRUE, 4),
  (9, 'Compresser une image', FALSE, 4);

INSERT INTO inscription (utilisateur_id, cours_id, progression) VALUES
  (3, 1, 0),
  (4, 2, 0);
