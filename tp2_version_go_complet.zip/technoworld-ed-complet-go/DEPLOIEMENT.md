# Lancement local

1. Installer Go 1.22+, MySQL 8 et, sous Windows, démarrer MySQL depuis XAMPP.
2. Créer la base et les données : `mysql -u root -p < sql/schema_and_seed.sql`.
3. Copier `.env.example` vers `.env` et adapter les paramètres MySQL.
4. Installer les dépendances : `go mod tidy`.
5. Lancer : `go run .`.
6. Ouvrir `http://localhost:8080`.

## Comptes de test

- admin@technoworld.test / password
- enseignant@technoworld.test / password
- apprenant1@technoworld.test / password
- apprenant2@technoworld.test / password

# Build et déploiement

`go build -o technoworld-ed .` puis définir les variables d’environnement sur le serveur et exécuter `./technoworld-ed`. Placer l’application derrière HTTPS, définir `COOKIE_SECURE=true`, utiliser un secret de session long et ne jamais exposer `.env`.

# Tests manuels

## Apprenant

- Inscription et connexion.
- Consultation et filtrage des cours publiés.
- Ouverture d’un cours et d’un quiz.
- Vérification que les bonnes réponses ne sont pas envoyées dans le HTML.
- Soumission du quiz et consultation de Mes résultats.
- Vérification des refus d’accès aux interfaces enseignant/admin.

## Enseignant

- Connexion avec le compte enseignant.
- Création, modification et suppression d’un cours.
- Vérification du statut `en_attente`.
- Ajout d’une leçon.
- Vérification qu’un cours d’un autre enseignant ne peut pas être modifié.

## Admin

- Validation et refus d’un cours.
- Modification des rôles utilisateurs.
- Ajout d’une catégorie.
- Vérification des protections CSRF et du contrôle de rôle.

## API

Tester `POST /api/register`, `POST /api/login`, `GET /api/cours`, `GET /api/cours/{id}`, `GET /api/quiz/{id}`, `POST /api/quiz/{id}/submit` et `GET /api/resultats`. Les réponses suivent l’enveloppe `{success,data,message}`.
