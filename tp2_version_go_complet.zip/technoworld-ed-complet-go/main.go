package main

// TechnoWorld Ed — application e-learning complète.
// Toutes les entrées sont validées côté serveur et les sorties HTML passent par html/template.

import (
	"errors"
	"fmt"
	"html/template"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"
	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
	"github.com/joho/godotenv"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

type Config struct {
	AppPort, SessionSecret, DBHost, DBPort, DBUser, DBPassword, DBName string
	CookieSecure                                                       bool
}

func loadConfig() Config {
	_ = godotenv.Load()
	secure := os.Getenv("COOKIE_SECURE") == "true"
	port := os.Getenv("APP_PORT")
	if port == "" {
		port = "8080"
	}
	return Config{port, env("SESSION_SECRET", "change-me-in-production"), env("DB_HOST", "127.0.0.1"), env("DB_PORT", "3306"), env("DB_USER", "root"), os.Getenv("DB_PASSWORD"), env("DB_NAME", "technoworld_ed"), secure}
}
func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

// Modèles GORM.
type User struct {
	ID         uint `gorm:"primaryKey"`
	Nom        string
	Email      string `gorm:"uniqueIndex"`
	MotDePasse string
	Role       string `gorm:"type:enum('apprenant','enseignant','admin');default:apprenant"`
	CreatedAt  time.Time
	UpdatedAt  time.Time
	Courses    []Course `gorm:"foreignKey:AuteurID"`
}
type Category struct {
	ID        uint   `gorm:"primaryKey"`
	Nom       string `gorm:"uniqueIndex"`
	CreatedAt time.Time
	UpdatedAt time.Time
}
type Course struct {
	ID          uint `gorm:"primaryKey"`
	Titre       string
	Description string
	Statut      string `gorm:"type:enum('brouillon','en_attente','publie','refuse');default:en_attente"`
	Prix        float64
	Acces       string `gorm:"type:enum('gratuit','premium');default:gratuit"`
	AuteurID    uint
	Auteur      User
	CategorieID uint
	Categorie   Category
	Lecons      []Lesson
	Quizzes     []Quiz
	CreatedAt   time.Time
	UpdatedAt   time.Time
}
type Lesson struct {
	ID        uint `gorm:"primaryKey"`
	Titre     string
	Contenu   string
	Ordre     int
	CoursID   uint
	CreatedAt time.Time
	UpdatedAt time.Time
}
type Quiz struct {
	ID        uint `gorm:"primaryKey"`
	Titre     string
	CoursID   uint
	Questions []Question
	CreatedAt time.Time
	UpdatedAt time.Time
}
type Question struct {
	ID        uint `gorm:"primaryKey"`
	Enonce    string
	QuizID    uint
	Reponses  []Answer
	CreatedAt time.Time
	UpdatedAt time.Time
}
type Answer struct {
	ID          uint `gorm:"primaryKey"`
	Texte       string
	EstCorrecte bool
	QuestionID  uint
	CreatedAt   time.Time
	UpdatedAt   time.Time
}
type Enrollment struct {
	UtilisateurID   uint `gorm:"primaryKey"`
	CoursID         uint `gorm:"primaryKey"`
	Progression     int
	DateInscription time.Time
	CreatedAt       time.Time
	UpdatedAt       time.Time
}
type Result struct {
	ID            uint `gorm:"primaryKey"`
	UtilisateurID uint
	QuizID        uint
	Score         int
	Total         int
	DatePassage   time.Time
	CreatedAt     time.Time
	UpdatedAt     time.Time
}

type App struct {
	db  *gorm.DB
	cfg Config
}

func (a *App) dsn() string {
	return fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=True&loc=Local", a.cfg.DBUser, a.cfg.DBPassword, a.cfg.DBHost, a.cfg.DBPort, a.cfg.DBName)
}
func currentUser(c *gin.Context, db *gorm.DB) *User {
	id, ok := sessions.Default(c).Get("user_id").(uint)
	if !ok || id == 0 {
		return nil
	}
	var u User
	if db.First(&u, id).Error != nil {
		return nil
	}
	return &u
}
func csrfToken(c *gin.Context) string {
	s := sessions.Default(c)
	token, ok := s.Get("csrf").(string)
	if !ok || token == "" {
		token = fmt.Sprintf("%d-%d", time.Now().UnixNano(), time.Now().Unix())
		s.Set("csrf", token)
		_ = s.Save()
	}
	return token
}
func validCSRF(c *gin.Context) bool {
	return c.PostForm("csrf") != "" && c.PostForm("csrf") == csrfToken(c)
}
func render(c *gin.Context, name string, data gin.H) {
	data["csrf"] = csrfToken(c)
	data["user"] = currentUser(c, c.MustGet("db").(*gorm.DB))
	c.HTML(http.StatusOK, name, data)
}

func role(required ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		u := currentUser(c, c.MustGet("db").(*gorm.DB))
		if u == nil {
			if strings.HasPrefix(c.Request.URL.Path, "/api/") {
				c.JSON(401, gin.H{"success": false, "message": "Authentification requise"})
			} else {
				c.Redirect(302, "/login")
			}
			c.Abort()
			return
		}
		for _, r := range required {
			if u.Role == r {
				c.Next()
				return
			}
		}
		if strings.HasPrefix(c.Request.URL.Path, "/api/") {
			c.JSON(403, gin.H{"success": false, "message": "Rôle insuffisant"})
		} else {
			c.String(403, "Accès refusé")
		}
		c.Abort()
	}
}
func formGuard() gin.HandlerFunc {
	return func(c *gin.Context) {
		if c.Request.Method == "POST" && !strings.HasPrefix(c.Request.URL.Path, "/api/") && !validCSRF(c) {
			c.String(403, "Jeton CSRF invalide")
			c.Abort()
			return
		}
		c.Next()
	}
}

func (a *App) home(c *gin.Context) {
	var courses []Course
	q := a.db.Preload("Categorie").Where("statut = ?", "publie")
	if cat := c.Query("categorie"); cat != "" {
		if id, e := strconv.Atoi(cat); e == nil {
			q = q.Where("categorie_id = ?", id)
		}
	}
	q.Find(&courses)
	var cats []Category
	a.db.Order("nom").Find(&cats)
	render(c, "index.html", gin.H{"courses": courses, "categories": cats})
}
func (a *App) loginPage(c *gin.Context) { render(c, "login.html", gin.H{}) }
func (a *App) login(c *gin.Context) {
	email := strings.TrimSpace(strings.ToLower(c.PostForm("email")))
	pass := c.PostForm("password")
	var u User
	if email == "" || len(pass) < 8 || a.db.Where("email = ?", email).First(&u).Error != nil || bcrypt.CompareHashAndPassword([]byte(u.MotDePasse), []byte(pass)) != nil {
		render(c, "login.html", gin.H{"error": "Identifiants invalides."})
		return
	}
	s := sessions.Default(c)
	s.Set("user_id", u.ID)
	_ = s.Save()
	c.Redirect(302, "/")
}
func (a *App) registerPage(c *gin.Context) { render(c, "register.html", gin.H{}) }
func (a *App) register(c *gin.Context) {
	nom := strings.TrimSpace(c.PostForm("nom"))
	email := strings.TrimSpace(strings.ToLower(c.PostForm("email")))
	pass := c.PostForm("password")
	if len(nom) < 2 || len(nom) > 120 || !strings.Contains(email, "@") || len(pass) < 8 {
		render(c, "register.html", gin.H{"error": "Nom, email ou mot de passe invalide (8 caractères minimum)."})
		return
	}
	h, _ := bcrypt.GenerateFromPassword([]byte(pass), bcrypt.DefaultCost)
	u := User{Nom: nom, Email: email, MotDePasse: string(h), Role: "apprenant"}
	if e := a.db.Create(&u).Error; e != nil {
		render(c, "register.html", gin.H{"error": "Cet email est déjà utilisé."})
		return
	}
	c.Redirect(302, "/login")
}
func logout(c *gin.Context) { s := sessions.Default(c); s.Clear(); _ = s.Save(); c.Redirect(302, "/") }

func (a *App) course(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	var course Course
	if a.db.Preload("Lecons", func(db *gorm.DB) *gorm.DB { return db.Order("ordre") }).Preload("Categorie").Preload("Quizzes").First(&course, id).Error != nil {
		c.String(404, "Cours introuvable")
		return
	}
	render(c, "course.html", gin.H{"course": course})
}
func (a *App) teacherCourses(c *gin.Context) {
	u := currentUser(c, a.db)
	var courses []Course
	a.db.Preload("Categorie").Where("auteur_id = ?", u.ID).Find(&courses)
	render(c, "teacher_courses.html", gin.H{"courses": courses})
}
func (a *App) courseCreate(c *gin.Context) {
	var cats []Category
	a.db.Find(&cats)
	render(c, "course_form.html", gin.H{"categories": cats, "title": "Créer un cours"})
}
func (a *App) courseStore(c *gin.Context) {
	u := currentUser(c, a.db)
	title := strings.TrimSpace(c.PostForm("titre"))
	desc := strings.TrimSpace(c.PostForm("description"))
	cat, _ := strconv.Atoi(c.PostForm("categorie_id"))
	if len(title) < 3 || desc == "" || cat < 1 {
		c.String(400, "Données invalides")
		return
	}
	a.db.Create(&Course{Titre: title, Description: desc, Statut: "en_attente", Acces: "gratuit", AuteurID: u.ID, CategorieID: uint(cat)})
	c.Redirect(302, "/enseignant/cours")
}
func (a *App) courseEdit(c *gin.Context) {
	u := currentUser(c, a.db)
	id, _ := strconv.Atoi(c.Param("id"))
	var course Course
	if a.db.Where("id = ? AND auteur_id = ?", id, u.ID).First(&course).Error != nil {
		c.String(403, "Cours introuvable ou non autorisé")
		return
	}
	var cats []Category
	a.db.Find(&cats)
	render(c, "course_form.html", gin.H{"course": course, "categories": cats, "title": "Modifier un cours"})
}
func (a *App) courseUpdate(c *gin.Context) {
	u := currentUser(c, a.db)
	id, _ := strconv.Atoi(c.Param("id"))
	var course Course
	if a.db.Where("id = ? AND auteur_id = ?", id, u.ID).First(&course).Error != nil {
		c.String(403, "Non autorisé")
		return
	}
	cat, _ := strconv.Atoi(c.PostForm("categorie_id"))
	course.Titre = strings.TrimSpace(c.PostForm("titre"))
	course.Description = strings.TrimSpace(c.PostForm("description"))
	course.CategorieID = uint(cat)
	course.Statut = "en_attente"
	a.db.Save(&course)
	c.Redirect(302, "/enseignant/cours")
}
func (a *App) courseDelete(c *gin.Context) {
	u := currentUser(c, a.db)
	id, _ := strconv.Atoi(c.Param("id"))
	var course Course
	if a.db.Where("id = ? AND auteur_id = ?", id, u.ID).First(&course).Error != nil {
		c.String(403, "Non autorisé")
		return
	}
	a.db.Delete(&course)
	c.Redirect(302, "/enseignant/cours")
}
func (a *App) lessonStore(c *gin.Context) {
	u := currentUser(c, a.db)
	id, _ := strconv.Atoi(c.Param("id"))
	var course Course
	if a.db.Where("id = ? AND auteur_id = ?", id, u.ID).First(&course).Error != nil {
		c.String(403, "Non autorisé")
		return
	}
	order, _ := strconv.Atoi(c.PostForm("ordre"))
	if order < 1 {
		order = 1
	}
	a.db.Create(&Lesson{Titre: strings.TrimSpace(c.PostForm("titre")), Contenu: c.PostForm("contenu"), Ordre: order, CoursID: course.ID})
	c.Redirect(302, fmt.Sprintf("/cours/%d", course.ID))
}

func (a *App) quiz(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	var q Quiz
	if a.db.Preload("Questions.Reponses").First(&q, id).Error != nil {
		c.String(404, "Quiz introuvable")
		return
	}
	for i := range q.Questions {
		for j := range q.Questions[i].Reponses {
			q.Questions[i].Reponses[j].EstCorrecte = false
		}
	}
	render(c, "quiz.html", gin.H{"quiz": q})
}
func (a *App) submitQuiz(c *gin.Context) {
	u := currentUser(c, a.db)
	id, _ := strconv.Atoi(c.Param("id"))
	var q Quiz
	if a.db.Preload("Questions.Reponses").First(&q, id).Error != nil {
		c.String(404, "Quiz introuvable")
		return
	}
	score := 0
	for _, question := range q.Questions {
		chosen, _ := strconv.ParseUint(c.PostForm(fmt.Sprintf("question_%d", question.ID)), 10, 64)
		for _, answer := range question.Reponses {
			if answer.EstCorrecte && uint(chosen) == answer.ID {
				score++
			}
		}
	}
	a.db.Create(&Result{UtilisateurID: u.ID, QuizID: q.ID, Score: score, Total: len(q.Questions), DatePassage: time.Now()})
	render(c, "quiz_result.html", gin.H{"score": score, "total": len(q.Questions)})
}
func (a *App) results(c *gin.Context) {
	u := currentUser(c, a.db)
	var results []Result
	a.db.Where("utilisateur_id = ?", u.ID).Order("date_passage DESC").Find(&results)
	render(c, "results.html", gin.H{"results": results})
}

func (a *App) adminCourses(c *gin.Context) {
	var courses []Course
	a.db.Preload("Auteur").Preload("Categorie").Order("created_at desc").Find(&courses)
	render(c, "admin_courses.html", gin.H{"courses": courses})
}
func (a *App) adminCourseAction(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	action := c.PostForm("action")
	if action != "publie" && action != "refuse" {
		c.String(400, "Action invalide")
		return
	}
	a.db.Model(&Course{}).Where("id = ?", id).Update("statut", action)
	c.Redirect(302, "/admin/cours")
}
func (a *App) adminUsers(c *gin.Context) {
	var users []User
	a.db.Order("id").Find(&users)
	render(c, "admin_users.html", gin.H{"users": users})
}
func (a *App) adminUserAction(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	if id == 1 {
		c.String(400, "Compte protégé")
		return
	}
	role := c.PostForm("role")
	if role != "admin" && role != "enseignant" && role != "apprenant" {
		c.String(400, "Rôle invalide")
		return
	}
	a.db.Model(&User{}).Where("id = ?", id).Update("role", role)
	c.Redirect(302, "/admin/utilisateurs")
}
func (a *App) adminCategories(c *gin.Context) {
	var cats []Category
	a.db.Find(&cats)
	render(c, "admin_categories.html", gin.H{"categories": cats})
}
func (a *App) adminCategoryStore(c *gin.Context) {
	name := strings.TrimSpace(c.PostForm("nom"))
	if len(name) < 2 || len(name) > 120 {
		c.String(400, "Nom invalide")
		return
	}
	a.db.Create(&Category{Nom: name})
	c.Redirect(302, "/admin/categories")
}

func apiOK(c *gin.Context, data any, msg string) {
	c.JSON(200, gin.H{"success": true, "data": data, "message": msg})
}
func (a *App) apiRegister(c *gin.Context) {
	var in struct{ Nom, Email, Password string }
	if c.ShouldBindJSON(&in) != nil || len(in.Nom) < 2 || !strings.Contains(in.Email, "@") || len(in.Password) < 8 {
		c.JSON(400, gin.H{"success": false, "message": "Données invalides"})
		return
	}
	h, _ := bcrypt.GenerateFromPassword([]byte(in.Password), bcrypt.DefaultCost)
	u := User{Nom: strings.TrimSpace(in.Nom), Email: strings.ToLower(strings.TrimSpace(in.Email)), MotDePasse: string(h), Role: "apprenant"}
	if e := a.db.Create(&u).Error; e != nil {
		c.JSON(409, gin.H{"success": false, "message": "Email déjà utilisé"})
		return
	}
	apiOK(c, gin.H{"id": u.ID, "email": u.Email}, "Compte créé")
}
func (a *App) apiLogin(c *gin.Context) {
	var in struct{ Email, Password string }
	if c.ShouldBindJSON(&in) != nil {
		c.JSON(400, gin.H{"success": false, "message": "JSON invalide"})
		return
	}
	var u User
	if a.db.Where("email = ?", strings.ToLower(strings.TrimSpace(in.Email))).First(&u).Error != nil || bcrypt.CompareHashAndPassword([]byte(u.MotDePasse), []byte(in.Password)) != nil {
		c.JSON(401, gin.H{"success": false, "message": "Identifiants invalides"})
		return
	}
	s := sessions.Default(c)
	s.Set("user_id", u.ID)
	_ = s.Save()
	apiOK(c, gin.H{"id": u.ID, "role": u.Role}, "Connexion réussie")
}
func (a *App) apiCourses(c *gin.Context) {
	var courses []Course
	a.db.Preload("Categorie").Where("statut = ?", "publie").Find(&courses)
	apiOK(c, courses, "Cours publiés")
}
func (a *App) apiCourse(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	var course Course
	if a.db.Preload("Lecons").Preload("Categorie").Where("id = ? AND statut = ?", id, "publie").First(&course).Error != nil {
		c.JSON(404, gin.H{"success": false, "message": "Cours introuvable"})
		return
	}
	apiOK(c, course, "Cours trouvé")
}
func (a *App) apiQuiz(c *gin.Context) {
	id, _ := strconv.Atoi(c.Param("id"))
	var q Quiz
	if a.db.Preload("Questions.Reponses").First(&q, id).Error != nil {
		c.JSON(404, gin.H{"success": false, "message": "Quiz introuvable"})
		return
	}
	for i := range q.Questions {
		for j := range q.Questions[i].Reponses {
			q.Questions[i].Reponses[j].EstCorrecte = false
		}
	}
	apiOK(c, q, "Quiz trouvé")
}
func (a *App) apiSubmit(c *gin.Context) {
	u := currentUser(c, a.db)
	id, _ := strconv.Atoi(c.Param("id"))
	var in struct{ Answers map[string]uint }
	if c.ShouldBindJSON(&in) != nil {
		c.JSON(400, gin.H{"success": false, "message": "JSON invalide"})
		return
	}
	var q Quiz
	if a.db.Preload("Questions.Reponses").First(&q, id).Error != nil {
		c.JSON(404, gin.H{"success": false, "message": "Quiz introuvable"})
		return
	}
	score := 0
	for _, question := range q.Questions {
		for _, answer := range question.Reponses {
			if answer.EstCorrecte && in.Answers[strconv.Itoa(int(question.ID))] == answer.ID {
				score++
			}
		}
	}
	r := Result{UtilisateurID: u.ID, QuizID: q.ID, Score: score, Total: len(q.Questions), DatePassage: time.Now()}
	a.db.Create(&r)
	apiOK(c, gin.H{"score": score, "total": r.Total}, "Résultat enregistré")
}
func (a *App) apiResults(c *gin.Context) {
	u := currentUser(c, a.db)
	var r []Result
	a.db.Where("utilisateur_id = ?", u.ID).Find(&r)
	apiOK(c, r, "Résultats")
}

func main() {
	cfg := loadConfig()
	db, e := gorm.Open(mysql.Open(fmt.Sprintf("%s?parseTime=True", (&App{cfg: cfg}).dsn())), &gorm.Config{})
	if e != nil {
		panic("connexion MySQL impossible: " + e.Error())
	}
	app := &App{db: db, cfg: cfg}
	r := gin.Default()
	r.Use(func(c *gin.Context) { c.Set("db", db); c.Next() })
	store := cookie.NewStore([]byte(cfg.SessionSecret))
	store.Options(sessions.Options{Path: "/", HttpOnly: true, Secure: cfg.CookieSecure, SameSite: http.SameSiteLaxMode, MaxAge: 86400})
	r.Use(sessions.Sessions("technoworld_session", store), formGuard())
	r.SetFuncMap(template.FuncMap{"add": func(a, b int) int { return a + b }})
	r.LoadHTMLGlob("templates/*.html")
	r.Static("/static", "./static")
	r.GET("/", app.home)
	r.GET("/login", app.loginPage)
	r.POST("/login", app.login)
	r.GET("/register", app.registerPage)
	r.POST("/register", app.register)
	r.POST("/logout", role("apprenant", "enseignant", "admin"), logout)
	r.GET("/cours/:id", app.course)
	r.GET("/quiz/:id", role("apprenant", "enseignant", "admin"), app.quiz)
	r.POST("/quiz/:id/submit", role("apprenant", "enseignant", "admin"), app.submitQuiz)
	r.GET("/mes-resultats", role("apprenant", "enseignant", "admin"), app.results)
	t := r.Group("/enseignant", role("enseignant", "admin"))
	t.GET("/cours", app.teacherCourses)
	t.GET("/cours/nouveau", app.courseCreate)
	t.POST("/cours", app.courseStore)
	t.GET("/cours/:id/modifier", app.courseEdit)
	t.POST("/cours/:id", app.courseUpdate)
	t.POST("/cours/:id/supprimer", app.courseDelete)
	t.POST("/cours/:id/lecons", app.lessonStore)
	ad := r.Group("/admin", role("admin"))
	ad.GET("/cours", app.adminCourses)
	ad.POST("/cours/:id", app.adminCourseAction)
	ad.GET("/utilisateurs", app.adminUsers)
	ad.POST("/utilisateurs/:id", app.adminUserAction)
	ad.GET("/categories", app.adminCategories)
	ad.POST("/categories", app.adminCategoryStore)
	api := r.Group("/api")
	api.POST("/login", app.apiLogin)
	api.POST("/register", app.apiRegister)
	api.GET("/cours", app.apiCourses)
	api.GET("/cours/:id", app.apiCourse)
	api.GET("/quiz/:id", app.apiQuiz)
	protected := api.Group("", role("apprenant", "enseignant", "admin"))
	protected.POST("/quiz/:id/submit", app.apiSubmit)
	protected.GET("/resultats", app.apiResults)
	fmt.Printf("TechnoWorld Ed écoute sur http://localhost:%s\n", cfg.AppPort)
	if e := r.Run(":" + cfg.AppPort); e != nil && !errors.Is(e, http.ErrServerClosed) {
		panic(e)
	}
}
